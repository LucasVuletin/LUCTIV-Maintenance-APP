# LUCTIV

Aplicación web para visualizar y gestionar el spread de bombas durante operaciones de fractura hidráulica.

## Funciones principales

- Layout operativo de bombas por manifold, lado y posición.
- Estados de operación y movimientos de entrada, salida o mantenimiento.
- Identificación de circuitos LIMPIO y SUCIO.
- Registro de pad, pozo, etapa y SET.
- Planificación de tareas de mantenimiento PE e IEM.
- Alertas acumulables ante bombas OFFLINE.
- Recomendaciones de reemplazo con confirmación o justificación.
- Captura PNG del layout.
- Exportación Excel de configuración, mantenimiento, historial y alertas operativas.
- Persistencia local para uso en campo.
- Soporte PWA para instalación y operación en modo kiosco.

## Requisitos

- Node.js 20 o superior.
- npm 10 o superior.

## Instalación

```bash
npm install
```

En equipos Windows con restricciones de PowerShell:

```powershell
npm.cmd install
```

## Desarrollo local

```bash
npm run dev
```

En PowerShell:

```powershell
npm.cmd run dev
```

La aplicación queda disponible normalmente en `http://localhost:5173`.

## Validación

```bash
npm run typecheck
npm run build
```

La salida de producción se genera en `dist/`.

## Estructura

```text
src/
  components/        Componentes visuales y flujos operativos
  data/              Configuración inicial de bombas y manifolds
  hooks/             Persistencia y estado reutilizable
  utils/             Layout, validaciones, capturas y exportación Excel
  AppShell.tsx       Coordinación principal de la aplicación
  models.ts          Modelos y metadatos del dominio
  main.tsx           Punto de entrada
public/
  icons/             Iconos de la aplicación
  manifest.webmanifest
  sw.js
```

## Persistencia

La configuración se guarda en el navegador mediante `localStorage`. Cada conjunto de datos utiliza una clave y versión independientes para permitir migraciones controladas.

## Exportación operativa

El archivo Excel incluye:

- Resumen de la etapa.
- Bombas y manifolds.
- Slots y actuadores.
- Plan e historial entre etapas.
- Tareas de mantenimiento.
- Alertas operativas y respuestas.
- Campos recomendados para análisis.

## Despliegue

El repositorio incluye `vercel.json` y está preparado para desplegar la carpeta `dist/` mediante Vercel.
