import { useState } from "react";
import { OperationalActionDecision, OperationalEvent } from "../models";

export type OperationalAlert = OperationalEvent;

type OperationalAlertModalProps = {
  alerts: OperationalAlert[];
  onClose: (alertId: string) => void;
  onResolve: (
    alertId: string,
    decision: Exclude<OperationalActionDecision, "pending">,
    comment: string,
  ) => void;
};

export function OperationalAlertModal({
  alerts,
  onClose,
  onResolve,
}: OperationalAlertModalProps) {
  const [comments, setComments] = useState<Record<string, string>>({});
  const [commentErrors, setCommentErrors] = useState<Record<string, string>>({});

  if (alerts.length === 0) {
    return null;
  }

  return (
    <div
      aria-label="Notificaciones operativas"
      className="pointer-events-none fixed inset-y-0 right-0 z-[120] flex w-full max-w-md flex-col justify-end gap-3 overflow-y-auto p-3 sm:p-5"
    >
      {alerts.map((alert) => {
        const isResolved = alert.decision !== "pending";

        function resolveAlert(
          decision: Exclude<OperationalActionDecision, "pending">,
        ) {
          const enteredComment = (comments[alert.id] ?? "").trim();

          if (decision === "not-possible" && !enteredComment) {
            setCommentErrors((currentErrors) => ({
              ...currentErrors,
              [alert.id]: "Justificá por qué no se puede realizar.",
            }));
            return;
          }

          setCommentErrors((currentErrors) => ({
            ...currentErrors,
            [alert.id]: "",
          }));
          onResolve(alert.id, decision, enteredComment || "OK");
        }

        return (
          <section
            key={alert.id}
            role="status"
            aria-label={`Bomba ${alert.pumpSap} offline`}
            className="pointer-events-auto w-full rounded-xl border-2 border-red-600 bg-black px-5 py-4 text-white"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.22em] text-white">
                  Alerta operativa · Prioridad {alert.priority}
                </p>
                <h2 className="mt-1 text-2xl font-black text-white">
                  Bomba {alert.pumpSap} OFFLINE
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onClose(alert.id)}
                aria-label={`Cerrar alerta de bomba ${alert.pumpSap}`}
                className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-white/40 text-lg font-black text-white hover:bg-white/10"
              >
                ×
              </button>
            </div>

            <p className="mt-3 text-sm font-semibold text-white">
              Bombeador caído por: {alert.offlineReason}
            </p>
            <p className="mt-3 border-l-2 border-red-600 pl-3 text-base font-semibold leading-6 text-white">
              {alert.recommendedAction}
            </p>

            {isResolved ? (
              <div className="mt-4 border-t border-white/25 pt-3 text-sm font-bold text-white">
                {alert.decision === "ok" ? "OK" : "No se puede realizar"} ·{" "}
                {alert.responseComment}
              </div>
            ) : (
              <>
                <label className="mt-4 block">
                  <span className="text-xs font-bold uppercase tracking-[0.16em] text-white">
                    Comentario
                  </span>
                  <textarea
                    value={comments[alert.id] ?? ""}
                    onChange={(event) =>
                      setComments((currentComments) => ({
                        ...currentComments,
                        [alert.id]: event.target.value,
                      }))
                    }
                    rows={2}
                    placeholder="OK o motivo por el que no se puede realizar"
                    className="mt-2 w-full resize-none rounded-lg border border-white/45 bg-black px-3 py-2 text-sm font-semibold text-white outline-none placeholder:text-white/50 focus:border-white"
                  />
                </label>
                {commentErrors[alert.id] ? (
                  <p className="mt-2 text-sm font-bold text-white">
                    {commentErrors[alert.id]}
                  </p>
                ) : null}
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => resolveAlert("ok")}
                    className="min-h-11 rounded-lg border border-white/55 bg-white px-3 font-black text-black hover:bg-slate-200"
                  >
                    OK
                  </button>
                  <button
                    type="button"
                    onClick={() => resolveAlert("not-possible")}
                    className="min-h-11 rounded-lg border border-white/55 bg-black px-3 font-black text-white hover:bg-white/10"
                  >
                    No se puede realizar
                  </button>
                </div>
              </>
            )}
          </section>
        );
      })}
    </div>
  );
}
