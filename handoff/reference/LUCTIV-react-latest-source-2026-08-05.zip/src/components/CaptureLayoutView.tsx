import { useEffect, useMemo, useState } from "react";
import { APP_BRAND_NAME } from "../appIdentity";
import {
  getNonOperationalReasonLabel,
  isPumpSetMovement,
  Manifold,
  Pump,
  PUMP_SET_MOVEMENT_META,
  SetNumber,
  WellStageContext,
} from "../models";
import { downloadCaptureLayoutPng } from "../utils/exportCaptureImage";
import {
  createSlotActuatorKey,
  getBenchPumps,
  getPumpStats,
  SlotActuatorMap,
} from "../utils/layoutState";

type CaptureLayoutViewProps = {
  manifolds: Manifold[];
  onClose: () => void;
  pumps: Pump[];
  selectedSet: SetNumber;
  slotActuators: SlotActuatorMap;
  stageContext: WellStageContext;
};

const CAPTURE_PANEL_CLASS =
  "border border-slate-700/60 bg-slate-950/62 shadow-[0_18px_60px_rgba(2,6,23,0.42)]";

function getModeLabel(stageContext: WellStageContext) {
  return stageContext.mode === "dual-simul" ? "Dual / Simul" : "Zipper";
}

function getStageLabel(stageContext: WellStageContext) {
  const primary = [
    stageContext.primary.well.trim() ? `Pozo ${stageContext.primary.well.trim()}` : "",
    stageContext.primary.stage.trim() ? `Etapa ${stageContext.primary.stage.trim()}` : "",
  ]
    .filter(Boolean)
    .join(" | ");
  const secondary =
    stageContext.mode === "dual-simul"
      ? [
          stageContext.secondary.well.trim()
            ? `Pozo ${stageContext.secondary.well.trim()}`
            : "",
          stageContext.secondary.stage.trim()
            ? `Etapa ${stageContext.secondary.stage.trim()}`
            : "",
        ]
          .filter(Boolean)
          .join(" | ")
      : "";

  return [primary, secondary].filter(Boolean).join(" / ") || "Pozo y etapa sin cargar";
}

function getPumpAtSlot(
  pumps: Pump[],
  manifoldId: string,
  side: "left" | "right",
  position: number,
) {
  return (
    pumps.find(
      (pump) =>
        pump.side === side &&
        pump.manifoldId === manifoldId &&
        pump.position === position,
    ) ?? null
  );
}

function getSetMovementLabel(pump: Pump) {
  return pump.setMovementEdited === true && isPumpSetMovement(pump.setMovement)
    ? PUMP_SET_MOVEMENT_META[pump.setMovement].label
    : null;
}

function buildPumpPdsLine(pump: Pump) {
  return `P${pump.signals.p} D${pump.signals.d} S${pump.signals.s}`;
}

function getPumpComment(pump: Pump) {
  const movementComment = pump.setMovementComment.trim();
  const nonOperationalReason =
    pump.operationState === "non-operative" && pump.nonOperationalReason
      ? `NO OP ${getNonOperationalReasonLabel(pump.nonOperationalReason)}`
      : "";

  return [nonOperationalReason, movementComment].filter(Boolean).join(": ");
}

function buildCommentsLine(pumps: Pump[]) {
  return pumps
    .map((pump) => {
      const comment = getPumpComment(pump);
      const movementLabel = getSetMovementLabel(pump);

      if (!comment && !movementLabel) {
        return "";
      }

      return `${pump.sap}${movementLabel ? ` ${movementLabel}` : ""}${comment ? `: ${comment}` : ""}`;
    })
    .filter(Boolean)
    .join(" | ");
}

function CaptureMetric({
  label,
  value,
}: {
  label: string;
  value: string | number;
}) {
  return (
    <div className="min-w-0 rounded-xl border border-slate-700/70 bg-slate-950/55 px-3 py-2">
      <p className="truncate text-[0.62rem] font-semibold uppercase text-slate-400">
        {label}
      </p>
      <p className="mt-1 truncate text-xl font-black leading-none text-slate-50">
        {value}
      </p>
    </div>
  );
}

function CapturePumpCard({
  actuatorValue = "",
  connectionColorClass,
  emptyLabel,
  pump,
  variant = "slot",
}: {
  actuatorValue?: string;
  connectionColorClass: string;
  emptyLabel: string;
  pump: Pump | null;
  variant?: "slot" | "reserve";
}) {
  if (!pump) {
    return (
      <div className="flex h-full min-h-0 items-center justify-center rounded-xl border border-dashed border-slate-600/55 bg-slate-950/28 px-2 text-xs font-semibold text-slate-500">
        {emptyLabel}
      </div>
    );
  }

  const isOperative = pump.operationState === "operative";
  const pdsLine = buildPumpPdsLine(pump);
  const isReserve = variant === "reserve";

  return (
    <article
      className={`relative flex h-full min-h-0 overflow-hidden rounded-xl border bg-[#081527] px-2 py-1 ${
        isOperative ? "border-emerald-300/45" : "border-red-300/55"
      }`}
    >
      <div className="relative min-w-0 flex-1">
        <div className="absolute inset-x-0 top-0 z-10 flex min-w-0 items-center justify-end gap-1">
          {actuatorValue ? (
            <span className="rounded-md border border-slate-600/70 bg-slate-950/70 px-1.5 py-0.5 font-mono text-[0.58rem] font-black leading-none text-slate-50">
              {actuatorValue}
            </span>
          ) : null}
        </div>

        <p
          className={
            isReserve
              ? "absolute inset-x-2 top-[37%] -translate-y-1/2 truncate text-center font-mono text-[clamp(0.95rem,1.9vh,1.18rem)] font-black leading-none text-slate-50"
              : "absolute left-2 top-1/2 w-[52%] -translate-y-1/2 truncate text-center font-mono text-[clamp(1.08rem,2.35vh,1.38rem)] font-black leading-none text-slate-50"
          }
        >
          {pump.sap}
        </p>

        <p
          className={
            isReserve
              ? "absolute inset-x-1 bottom-1.5 truncate text-center font-mono text-[0.42rem] font-black uppercase leading-none text-[#DBE8EE]"
              : "absolute right-2 top-1/2 w-[42%] -translate-y-1/2 truncate text-right font-mono text-[0.58rem] font-black uppercase leading-none text-[#DBE8EE]"
          }
          title={pdsLine}
        >
          {pdsLine}
        </p>
        <div className={`absolute inset-x-1 bottom-[0.2rem] h-px rounded-full opacity-45 ${connectionColorClass}`} />
      </div>
    </article>
  );
}

function CaptureManifold({
  manifold,
  pumps,
  slotActuators,
}: {
  manifold: Manifold;
  pumps: Pump[];
  slotActuators: SlotActuatorMap;
}) {
  const connectionColorClass = manifold.type === "clean" ? "bg-[#7FB3C8]" : "bg-[#8B6A4A]";
  const typeLabel = manifold.type === "clean" ? "Limpio" : "Sucio";
  const slotCount = Math.max(manifold.pumpsPerSide, 1);
  const assignedPumps = pumps.filter(
    (pump) => pump.side !== "bench" && pump.manifoldId === manifold.id,
  );
  const commentsLine = buildCommentsLine(assignedPumps);
  const operativeCount = assignedPumps.filter(
    (pump) => pump.operationState === "operative",
  ).length;

  return (
    <section className={`grid min-h-0 grid-rows-[auto_minmax(0,1fr)] rounded-2xl p-3 ${CAPTURE_PANEL_CLASS}`}>
      <div className="mb-2 flex min-w-0 items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-xl font-black leading-none text-slate-50">
            {manifold.label} | {typeLabel}
          </p>
          <p className="mt-1 truncate text-xs font-semibold uppercase text-slate-400">
            {assignedPumps.length} bombas | {manifold.pumpsPerSide} slots por lado
          </p>
          {commentsLine ? (
            <p className="mt-1 truncate text-[0.68rem] font-semibold text-amber-100/90">
              Comentarios: {commentsLine}
            </p>
          ) : null}
        </div>
        <div className="flex shrink-0 gap-2 text-xs font-black">
          <span className="rounded-full border border-emerald-300/25 bg-emerald-400/10 px-2.5 py-1 text-emerald-100">
            OP {operativeCount}
          </span>
          <span className="rounded-full border border-red-300/25 bg-red-400/10 px-2.5 py-1 text-red-100">
            NO OP {assignedPumps.length - operativeCount}
          </span>
        </div>
      </div>

      <div className="grid min-h-0 grid-cols-[minmax(0,1fr)_3.5rem_minmax(0,1fr)] gap-2">
        <div
          className="grid min-h-0 gap-1"
          style={{ gridTemplateRows: `repeat(${slotCount}, minmax(0, 1fr))` }}
        >
          {Array.from({ length: slotCount }, (_, index) => {
            const position = index + 1;
            const pump = getPumpAtSlot(pumps, manifold.id, "left", position);
            const actuatorValue =
              slotActuators[
                createSlotActuatorKey({ manifoldId: manifold.id, position, side: "left" })
              ] ?? "";

            return (
              <CapturePumpCard
                key={`${manifold.id}-left-${position}`}
                actuatorValue={actuatorValue}
                connectionColorClass={connectionColorClass}
                emptyLabel={`Slot ${position}`}
                pump={pump}
              />
            );
          })}
        </div>

        <div className="relative min-h-0">
          <div className="absolute inset-y-0 left-1/2 w-7 -translate-x-1/2 rounded-full border border-slate-700/70 bg-slate-950/85" />
          <div className={`absolute inset-y-4 left-1/2 w-1 -translate-x-1/2 rounded-full ${connectionColorClass}`} />
        </div>

        <div
          className="grid min-h-0 gap-1"
          style={{ gridTemplateRows: `repeat(${slotCount}, minmax(0, 1fr))` }}
        >
          {Array.from({ length: slotCount }, (_, index) => {
            const position = index + 1;
            const pump = getPumpAtSlot(pumps, manifold.id, "right", position);
            const actuatorValue =
              slotActuators[
                createSlotActuatorKey({ manifoldId: manifold.id, position, side: "right" })
              ] ?? "";

            return (
              <CapturePumpCard
                key={`${manifold.id}-right-${position}`}
                actuatorValue={actuatorValue}
                connectionColorClass={connectionColorClass}
                emptyLabel={`Slot ${position}`}
                pump={pump}
              />
            );
          })}
        </div>
      </div>
    </section>
  );
}

function CaptureReserve({
  pumps,
}: {
  pumps: Pump[];
}) {
  const columnCount = Math.max(1, Math.min(pumps.length || 1, 4));
  const rowCount = Math.max(1, Math.ceil((pumps.length || 1) / columnCount));
  const commentsLine = buildCommentsLine(pumps);

  return (
    <section className={`grid min-h-0 grid-rows-[auto_minmax(0,1fr)] rounded-2xl p-3 ${CAPTURE_PANEL_CLASS}`}>
      <div className="mb-2 min-w-0">
        <div className="flex items-center justify-between gap-3">
          <p className="truncate text-lg font-black text-slate-50">
            Fuera del set / reserva
          </p>
          <span className="rounded-full border border-slate-600/70 bg-slate-950/60 px-3 py-1 text-xs font-black text-slate-200">
            {pumps.length}
          </span>
        </div>
        {commentsLine ? (
          <p className="mt-1 truncate text-[0.68rem] font-semibold text-amber-100/90">
            Comentarios: {commentsLine}
          </p>
        ) : null}
      </div>

      {pumps.length > 0 ? (
        <div
          className="grid min-h-0 gap-2"
          style={{
            gridTemplateColumns: `repeat(${columnCount}, minmax(0, 1fr))`,
            gridTemplateRows: `repeat(${rowCount}, minmax(0, 1fr))`,
          }}
        >
          {pumps.map((pump) => (
            <CapturePumpCard
              key={pump.id}
              connectionColorClass="bg-slate-500"
              emptyLabel=""
              pump={pump}
              variant="reserve"
            />
          ))}
        </div>
      ) : (
        <div className="flex min-h-0 items-center justify-center rounded-xl border border-dashed border-slate-600/50 bg-slate-950/30 text-sm font-semibold text-slate-500">
          Sin bombas fuera del set
        </div>
      )}
    </section>
  );
}

export function CaptureLayoutView({
  manifolds,
  onClose,
  pumps,
  selectedSet,
  slotActuators,
  stageContext,
}: CaptureLayoutViewProps) {
  const [areControlsHidden, setAreControlsHidden] = useState(false);
  const [downloadState, setDownloadState] = useState<"idle" | "working" | "done" | "failed">("idle");
  const stats = useMemo(() => getPumpStats(pumps), [pumps]);
  const benchPumps = useMemo(() => getBenchPumps(pumps), [pumps]);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
      }
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [onClose]);

  async function handleDownloadPng() {
    setDownloadState("working");

    try {
      await downloadCaptureLayoutPng({
        manifolds,
        pumps,
        selectedSet,
        slotActuators,
        stageContext,
      });
      setDownloadState("done");
      window.setTimeout(() => setDownloadState("idle"), 1800);
    } catch (error) {
      console.warn("No se pudo generar la captura PNG:", error);
      setDownloadState("failed");
    }
  }

  return (
    <section
      aria-label="Modo captura de layout"
      className={`fixed inset-0 z-[100] grid overflow-hidden bg-[#020617] p-2 text-slate-50 sm:p-3 ${
        areControlsHidden ? "grid-rows-[minmax(0,1fr)]" : "grid-rows-[auto_minmax(0,1fr)]"
      } gap-2`}
    >
      {!areControlsHidden ? (
        <div className="z-20 flex flex-wrap justify-end gap-2 rounded-2xl border border-slate-700/70 bg-slate-950/92 p-2 shadow-[0_18px_50px_rgba(0,0,0,0.55)]">
          <button
            type="button"
            onClick={() => {
              void handleDownloadPng();
            }}
            disabled={downloadState === "working"}
            className="min-h-11 rounded-xl border border-[#7FB3C8]/45 bg-[#7FB3C8]/12 px-4 text-sm font-black text-[#DBE8EE] transition hover:bg-[#7FB3C8]/20 disabled:cursor-wait disabled:opacity-60"
          >
            {downloadState === "working"
              ? "Generando..."
              : downloadState === "done"
                ? "PNG listo"
                : downloadState === "failed"
                  ? "Reintentar PNG"
                  : "Descargar PNG"}
          </button>
          <button
            type="button"
            onClick={() => setAreControlsHidden(true)}
            className="min-h-11 rounded-xl border border-slate-600/70 bg-slate-950/80 px-4 text-sm font-black text-slate-200 transition hover:border-slate-400/70"
          >
            Ocultar controles
          </button>
          <button
            type="button"
            onClick={onClose}
            className="min-h-11 rounded-xl border border-red-300/35 bg-red-500/12 px-4 text-sm font-black text-red-100 transition hover:bg-red-500/20"
          >
            Salir
          </button>
        </div>
      ) : null}

      <div className="grid h-full min-h-0 grid-rows-[auto_minmax(0,1fr)_minmax(7.5rem,15vh)] gap-2">
        <header className={`grid min-h-0 grid-cols-[minmax(0,1fr)_auto] gap-3 rounded-2xl px-4 py-3 ${CAPTURE_PANEL_CLASS}`}>
          <div className="min-w-0">
            <p className="truncate text-4xl font-black uppercase leading-none text-slate-50">
              {APP_BRAND_NAME}
            </p>
            <p className="mt-2 truncate text-xl font-black text-[#DBE8EE]">
              {stageContext.pad.trim() || "Pad sin cargar"}
            </p>
            <p className="mt-1 truncate text-base font-semibold text-slate-300">
              {getStageLabel(stageContext)}
            </p>
          </div>

          <div className="grid w-[min(44vw,34rem)] grid-cols-3 gap-2">
            <CaptureMetric label="SET" value={selectedSet} />
            <CaptureMetric label="Modalidad" value={getModeLabel(stageContext)} />
            <CaptureMetric label="DGB" value={`${stats.dgbSubstitutionPercentage}%`} />
            <CaptureMetric label="En set" value={stats.totalInSet} />
            <CaptureMetric label="OP" value={stats.operativeInSetCount} />
            <CaptureMetric label="NO OP" value={stats.nonOperativeInSetCount} />
          </div>
        </header>

        <main
          className="grid min-h-0 gap-2"
          style={{
            gridTemplateRows: `repeat(${Math.max(manifolds.length, 1)}, minmax(0, 1fr))`,
          }}
        >
          {manifolds.length > 0 ? (
            manifolds.map((manifold) => (
              <CaptureManifold
                key={manifold.id}
                manifold={manifold}
                pumps={pumps}
                slotActuators={slotActuators}
              />
            ))
          ) : (
            <div className={`flex min-h-0 items-center justify-center rounded-2xl text-xl font-black text-slate-400 ${CAPTURE_PANEL_CLASS}`}>
              Sin manifolds cargados
            </div>
          )}
        </main>

        <CaptureReserve pumps={benchPumps} />
      </div>
    </section>
  );
}
