import {
  DndContext,
  DragEndEvent,
  DragOverlay,
  DragStartEvent,
  MouseSensor,
  TouchSensor,
  rectIntersection,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import { startTransition, useEffect, useState } from "react";
import { AddManifoldModal } from "./components/AddManifoldModal";
import { AddPumpModal } from "./components/AddPumpModal";
import { APP_AUTHOR_CREDIT, APP_BRAND_NAME, APP_VERSION_LABEL } from "./appIdentity";
import { CaptureLayoutView } from "./components/CaptureLayoutView";
import { ControlHeader } from "./components/ControlHeader";
import { InterstagePlanner } from "./components/InterstagePlanner";
import { LayoutWorkspace } from "./components/LayoutWorkspace";
import { ManifoldEditModal } from "./components/ManifoldEditModal";
import {
  OperationalAlert,
  OperationalAlertModal,
} from "./components/OperationalAlertModal";
import { PumpEditModal } from "./components/PumpEditModal";
import { PumpReserve } from "./components/PumpReserve";
import { PumpUnitCard } from "./components/PumpUnitCard";
import { createDefaultManifolds } from "./data/defaultManifolds";
import { createDefaultPumps } from "./data/defaultPumps";
import { useLocalStorage } from "./hooks/useLocalStorage";
import {
  InterstageHistoryRecord,
  InterstagePlan,
  isPumpSetMovement,
  Manifold,
  OperationalActionDecision,
  OperationalEvent,
  Pump,
  SetNumber,
  WellStageContext,
} from "./models";
import {
  applyPumpEdits,
  createSlotActuatorKey,
  getBenchPumps,
  getPumpStats,
  movePumpToBench,
  normalizeSlotActuatorValue,
  parseSlotDropId,
  placePumpInSlot,
  SlotActuatorMap,
  SlotTarget,
} from "./utils/layoutState";

const PUMPS_STORAGE_KEY = "halliburton-frac-layout-pumps-v2";
const MANIFOLDS_STORAGE_KEY = "halliburton-frac-layout-manifolds-v2";
const SET_STORAGE_KEY = "halliburton-frac-layout-selected-set-v1";
const WELL_STAGE_STORAGE_KEY = "halliburton-frac-layout-well-stage-v1";
const SLOT_ACTUATORS_STORAGE_KEY = "halliburton-frac-layout-slot-actuators-v1";
const INTERSTAGE_PLAN_STORAGE_KEY = "halliburton-frac-layout-interstage-plan-v1";
const INTERSTAGE_HISTORY_STORAGE_KEY = "halliburton-frac-layout-interstage-history-v1";
const OPERATIONAL_EVENTS_STORAGE_KEY = "halliburton-frac-layout-operational-events-v1";

const FAILURE_SCENARIOS = [
  { priority: 1, category: "ECM", reason: "falla ECM", department: "IEM" },
  { priority: 2, category: "TCM", reason: "falla TCM", department: "IEM" },
  { priority: 3, category: "ACE", reason: "falla ACE", department: "IEM" },
  { priority: 4, category: "OCTIV UHM", reason: "alarma OCTIV UHM", department: "IEM" },
  { priority: 5, category: "Operador", reason: "condición operativa informada", department: "PE" },
] as const;

function getFullscreenState() {
  return typeof document !== "undefined" && Boolean(document.fullscreenElement);
}

function findPump(pumps: Pump[], pumpId: string | null) {
  return pumps.find((pump) => pump.id === pumpId) ?? null;
}

function findManifold(manifolds: Manifold[], manifoldId: string | null) {
  return manifolds.find((manifold) => manifold.id === manifoldId) ?? null;
}

function createEntityId(prefix: string) {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return `${prefix}-${crypto.randomUUID()}`;
  }

  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function createManifoldLabel(manifolds: Manifold[], type: Manifold["type"]) {
  const nextIndex = manifolds.filter((manifold) => manifold.type === type).length + 1;
  const prefix = type === "clean" ? "MFC" : "MFD";

  return `${prefix}-${String(nextIndex).padStart(2, "0")}`;
}

function createEmptyWellStageContext(): WellStageContext {
  return {
    mode: "single",
    pad: "LAJE-18",
    primary: {
      well: "72",
      stage: "10",
    },
    secondary: {
      well: "",
      stage: "",
    },
  };
}

function createInterstagePlan(): InterstagePlan {
  const createdAt = new Date().toISOString();

  return {
    id: createEntityId("interstage-plan"),
    nextStageContext: createEmptyWellStageContext(),
    stageLeadMinutes: 20,
    targetMinutes: 15,
    status: "planning",
    startedAt: null,
    endedAt: null,
    tasks: [],
    note: "",
    historyRecordId: null,
    updatedAt: createdAt,
  };
}

export default function AppShell() {
  const [pumps, setPumps] = useLocalStorage<Pump[]>(
    PUMPS_STORAGE_KEY,
    createDefaultPumps,
    4,
  );
  const [manifolds, setManifolds] = useLocalStorage<Manifold[]>(
    MANIFOLDS_STORAGE_KEY,
    createDefaultManifolds,
    4,
  );
  const [selectedSet, setSelectedSet] = useLocalStorage<SetNumber>(
    SET_STORAGE_KEY,
    5,
    3,
  );
  const [stageContext, setStageContext] = useLocalStorage<WellStageContext>(
    WELL_STAGE_STORAGE_KEY,
    createEmptyWellStageContext,
    3,
  );
  const [slotActuators, setSlotActuators] = useLocalStorage<SlotActuatorMap>(
    SLOT_ACTUATORS_STORAGE_KEY,
    {},
    3,
  );
  const [interstagePlan, setInterstagePlan, resetInterstagePlan] =
    useLocalStorage<InterstagePlan>(
      INTERSTAGE_PLAN_STORAGE_KEY,
      createInterstagePlan,
      4,
    );
  const [interstageHistory, setInterstageHistory] = useLocalStorage<
    InterstageHistoryRecord[]
  >(INTERSTAGE_HISTORY_STORAGE_KEY, [], 3);
  const [operationalEvents, setOperationalEvents] = useLocalStorage<
    OperationalEvent[]
  >(OPERATIONAL_EVENTS_STORAGE_KEY, [], 1);
  const [selectedPumpId, setSelectedPumpId] = useState<string | null>(null);
  const [selectedManifoldId, setSelectedManifoldId] = useState<string | null>(null);
  const [addPumpTarget, setAddPumpTarget] = useState<SlotTarget | null>(null);
  const [activeDragId, setActiveDragId] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(getFullscreenState);
  const [isAddPumpOpen, setIsAddPumpOpen] = useState(false);
  const [isAddManifoldOpen, setIsAddManifoldOpen] = useState(false);
  const [isCaptureOpen, setIsCaptureOpen] = useState(false);
  const [operationalAlerts, setOperationalAlerts] = useState<OperationalAlert[]>([]);
  const [isFailureSimulationPending, setIsFailureSimulationPending] =
    useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [layoutNotice, setLayoutNotice] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(MouseSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(TouchSensor, {
      activationConstraint: {
        delay: 120,
        tolerance: 8,
      },
    }),
  );

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(getFullscreenState());
    };

    document.addEventListener("fullscreenchange", handleFullscreenChange);

    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
    };
  }, []);

  useEffect(() => {
    setPumps((currentPumps) => {
      const needsPumpDefaults = currentPumps.some(
        (pump) =>
          typeof pump.isDgb !== "boolean" ||
          !Number.isInteger(pump.substitutionPercentage) ||
          pump.substitutionPercentage < 0 ||
          pump.substitutionPercentage > 100 ||
          typeof pump.substitutionError !== "string" ||
          (pump.signalColumnCount !== 3 && pump.signalColumnCount !== 5) ||
          typeof pump.setMovementEdited !== "boolean" ||
          (pump.setMovement !== null && !isPumpSetMovement(pump.setMovement)) ||
          (pump.setMovementEdited === true && !isPumpSetMovement(pump.setMovement)) ||
          (pump.setMovementEdited !== true && pump.setMovement !== null) ||
          typeof pump.setMovementComment !== "string",
      );

      if (!needsPumpDefaults) {
        return currentPumps;
      }

      return currentPumps.map((pump) => {
        const hasEditedSetMovement =
          pump.setMovementEdited === true && isPumpSetMovement(pump.setMovement);

        return {
          ...pump,
          isDgb: pump.isDgb === true,
          substitutionPercentage:
            pump.isDgb === true &&
            Number.isInteger(pump.substitutionPercentage) &&
            pump.substitutionPercentage >= 0 &&
            pump.substitutionPercentage <= 100
              ? pump.substitutionPercentage
              : 0,
          substitutionError:
            pump.isDgb === true && typeof pump.substitutionError === "string"
              ? pump.substitutionError
              : "",
          signalColumnCount: pump.signalColumnCount === 5 ? 5 : 3,
          setMovement: hasEditedSetMovement ? pump.setMovement : null,
          setMovementEdited: hasEditedSetMovement,
          setMovementComment:
            hasEditedSetMovement && typeof pump.setMovementComment === "string"
              ? pump.setMovementComment.trim()
              : "",
        };
      });
    });
  }, [setPumps]);

  useEffect(() => {
    if (!layoutNotice) {
      return undefined;
    }

    const timeoutId = window.setTimeout(() => {
      setLayoutNotice(null);
    }, 4200);

    return () => {
      window.clearTimeout(timeoutId);
    };
  }, [layoutNotice]);

  const benchPumps = getBenchPumps(pumps);
  const stats = getPumpStats(pumps);
  const selectedPump = findPump(pumps, selectedPumpId);
  const selectedManifold = findManifold(manifolds, selectedManifoldId);
  const activePump = findPump(pumps, activeDragId);

  function handleDragStart(event: DragStartEvent) {
    const pumpId = String(event.active.id);
    setActiveDragId(pumpId);

    if (selectedPumpId === pumpId) {
      setSelectedPumpId(null);
    }
  }

  function handleDragEnd(event: DragEndEvent) {
    const pumpId = String(event.active.id);
    const currentPump = findPump(pumps, pumpId);
    const dropId = event.over ? String(event.over.id) : null;
    const slotTarget = parseSlotDropId(dropId);

    setActiveDragId(null);

    if (!currentPump) {
      return;
    }

    if (!dropId || dropId === "zone-bench") {
      if (currentPump.side === "bench") {
        return;
      }

      startTransition(() => {
        setPumps(movePumpToBench(pumps, pumpId));
        setLayoutNotice(null);
      });
      return;
    }

    if (!slotTarget) {
      startTransition(() => {
        setPumps(movePumpToBench(pumps, pumpId));
      });
      setLayoutNotice(null);
      return;
    }

    const result = placePumpInSlot(pumps, manifolds, pumpId, slotTarget);

    startTransition(() => {
      if (!result.error) {
        setPumps(result.pumps);
      }

      setLayoutNotice(result.error);
    });
  }

  function handleToggleFullscreen() {
    const run = async () => {
      try {
        if (!document.fullscreenElement) {
          await document.documentElement.requestFullscreen();
          return;
        }

        await document.exitFullscreen();
      } catch (error) {
        console.warn("No se pudo cambiar a pantalla completa:", error);
      }
    };

    void run();
  }

  function handleSlotActuatorChange(target: SlotTarget, value: string) {
    const slotKey = createSlotActuatorKey(target);
    const nextValue = normalizeSlotActuatorValue(value);

    setSlotActuators((currentSlotActuators) => {
      const nextSlotActuators = {
        ...currentSlotActuators,
      };

      if (nextValue) {
        nextSlotActuators[slotKey] = nextValue;
        return nextSlotActuators;
      }

      delete nextSlotActuators[slotKey];
      return nextSlotActuators;
    });
  }

  function handleSavePump(updatedPump: Pump) {
    const result = applyPumpEdits(pumps, manifolds, updatedPump);

    startTransition(() => {
      if (!result.error) {
        setPumps(result.pumps);
        setSelectedPumpId(null);
      }

      setLayoutNotice(result.error);
    });

    return result.error;
  }

  function handleDeletePump(pumpId: string) {
    startTransition(() => {
      setPumps((currentPumps) => currentPumps.filter((pump) => pump.id !== pumpId));
    });

    setSelectedPumpId(null);
    setActiveDragId(null);
    setLayoutNotice("Bomba eliminada del layout.");
  }

  function handleAddPump(values: {
    sap: string;
    operationState: Pump["operationState"];
    nonOperationalReason: Pump["nonOperationalReason"];
    setMovement: Pump["setMovement"];
    setMovementEdited: Pump["setMovementEdited"];
    setMovementComment: Pump["setMovementComment"];
    isDgb: boolean;
    substitutionPercentage: number;
    substitutionError: string;
    signalColumnCount: Pump["signalColumnCount"];
    signals: Pump["signals"];
  }) {
    const benchCount = pumps.filter((pump) => pump.side === "bench").length;
    const newPump: Pump = {
      id: createEntityId("pump"),
      sap: values.sap,
      side: "bench",
      manifoldId: null,
      row: benchCount,
      connection: "none",
      operationState: values.operationState,
      nonOperationalReason: values.nonOperationalReason,
      setMovement: values.setMovement,
      setMovementEdited: values.setMovementEdited,
      setMovementComment: values.setMovementComment,
      position: benchCount + 1,
      isDgb: values.isDgb,
      substitutionPercentage: values.substitutionPercentage,
      substitutionError: values.substitutionError,
      signalColumnCount: values.signalColumnCount,
      signals: values.signals,
    };
    const nextPumps = [...pumps, newPump];
    const placementResult = addPumpTarget
      ? placePumpInSlot(nextPumps, manifolds, newPump.id, addPumpTarget)
      : { error: null, pumps: nextPumps };

    if (placementResult.error) {
      setLayoutNotice(placementResult.error);
      return;
    }

    startTransition(() => {
      setPumps(placementResult.pumps);
    });

    setLayoutNotice(addPumpTarget ? "Bomba agregada al slot seleccionado." : null);
    setAddPumpTarget(null);
    setIsAddPumpOpen(false);
  }

  function handleAddManifold(values: {
    type: Manifold["type"];
    pumpsPerSide: number;
  }) {
    startTransition(() => {
      setManifolds((currentManifolds) => [
        ...currentManifolds,
        {
          id: createEntityId("manifold"),
          label: createManifoldLabel(currentManifolds, values.type),
          type: values.type,
          pumpsPerSide: values.pumpsPerSide,
        },
      ]);
    });

    setLayoutNotice(null);
    setIsAddManifoldOpen(false);
  }

  function handleSaveManifold(updatedManifold: Manifold) {
    const occupiedPositions = pumps
      .filter(
        (pump) => pump.side !== "bench" && pump.manifoldId === updatedManifold.id,
      )
      .map((pump) => pump.position);
    const highestOccupiedPosition =
      occupiedPositions.length > 0 ? Math.max(...occupiedPositions) : 0;

    if (updatedManifold.pumpsPerSide < highestOccupiedPosition) {
      return `No se pueden reducir los slots a ${updatedManifold.pumpsPerSide}: hay una bomba en el slot ${highestOccupiedPosition}.`;
    }

    startTransition(() => {
      setManifolds((currentManifolds) =>
        currentManifolds.map((manifold) =>
          manifold.id === updatedManifold.id ? updatedManifold : manifold,
        ),
      );
      setPumps((currentPumps) =>
        currentPumps.map((pump) =>
          pump.manifoldId === updatedManifold.id && pump.connection !== "none"
            ? { ...pump, connection: updatedManifold.type }
            : pump,
        ),
      );
    });

    setSelectedManifoldId(null);
    setLayoutNotice("Manifold actualizado.");

    return null;
  }

  function handleSaveLayout() {
    if (!window.confirm("Esta de acuerdo con guardar el layout tal como esta configurado?")) {
      return;
    }

    setLayoutNotice("Layout guardado en este equipo.");
  }

  function handleClearLayout() {
    if (
      !window.confirm(
        "Esta de acuerdo con limpiar el layout? Se borraran todas las bombas y se conservaran los manifolds.",
      )
    ) {
      return;
    }

    startTransition(() => {
      setPumps([]);
    });

    setSelectedPumpId(null);
    setSelectedManifoldId(null);
    setAddPumpTarget(null);
    setActiveDragId(null);
    setIsAddPumpOpen(false);
    setIsAddManifoldOpen(false);
    setLayoutNotice("Layout limpio. Se conservaron los manifolds y se borraron las bombas.");
  }

  async function handleDownloadExcel() {
    setIsExporting(true);

    try {
      const { exportLayoutWorkbook } = await import("./utils/exportLayoutWorkbook");
      const fileName = await exportLayoutWorkbook({
        interstageHistory,
        interstagePlan,
        manifolds,
        operationalEvents,
        pumps,
        slotActuators,
        selectedSet,
        stageContext,
      });

      setLayoutNotice(`Excel descargado: ${fileName}`);
    } catch (error) {
      console.warn("No se pudo generar el archivo Excel:", error);
      setLayoutNotice("No se pudo generar el archivo Excel.");
    } finally {
      setIsExporting(false);
    }
  }

  function handleSimulatePumpFailure() {
    if (isFailureSimulationPending) {
      return;
    }

    const affectedPump =
      pumps.find(
        (pump) =>
          pump.side !== "bench" &&
          pump.operationState === "operative" &&
          pump.connection === "dirty",
      ) ??
      pumps.find(
        (pump) => pump.side !== "bench" && pump.operationState === "operative",
      );
    const replacementPump = pumps.find(
      (pump) => pump.side === "bench" && pump.operationState === "operative",
    );

    if (!affectedPump) {
      setLayoutNotice("No hay una bomba operativa en el set para simular la caída.");
      return;
    }

    const manifold = manifolds.find(
      (entry) => entry.id === affectedPump.manifoldId,
    );
    const lineLabel = affectedPump.connection === "clean" ? "LIMPIO" : "SUCIO";
    const inSetPumps = pumps
      .filter((pump) => pump.side !== "bench")
      .sort((firstPump, secondPump) => {
        const manifoldDifference = String(firstPump.manifoldId).localeCompare(
          String(secondPump.manifoldId),
        );

        return (
          manifoldDifference ||
          firstPump.side.localeCompare(secondPump.side) ||
          firstPump.position - secondPump.position
        );
      });
    const locationNumber = Math.min(
      34,
      Math.max(1, inSetPumps.findIndex((pump) => pump.id === affectedPump.id) + 1),
    );
    const scenario =
      FAILURE_SCENARIOS[operationalEvents.length % FAILURE_SCENARIOS.length];

    setIsFailureSimulationPending(true);
    setLayoutNotice(
      `Simulación activa: monitoreando bombas del circuito ${lineLabel}.`,
    );

    window.setTimeout(() => {
      setPumps((currentPumps) =>
        currentPumps.map((pump) =>
          pump.id === affectedPump.id
            ? {
                ...pump,
                operationState: "non-operative",
                nonOperationalReason: scenario.reason,
                setMovement: "maintenance",
                setMovementEdited: true,
                setMovementComment: "Caída detectada durante bombeo. Requiere diagnóstico.",
              }
            : pump,
        ),
      );
      const recommendedAction = replacementPump
        ? `Reemplazar ${affectedPump.sap} por ${replacementPump.sap} en ${lineLabel}, ubicación ${locationNumber}.`
        : `Retirar ${affectedPump.sap} de ${lineLabel}, ubicación ${locationNumber}, y preparar una unidad de respaldo.`;
      const event: OperationalEvent = {
        id: createEntityId("operational-alert"),
        createdAt: new Date().toISOString(),
        priority: scenario.priority,
        pumpId: affectedPump.id,
        pumpSap: affectedPump.sap,
        offlineReason: scenario.reason,
        category: scenario.category,
        department: scenario.department,
        lineLabel,
        manifoldLabel: manifold?.label ?? `Circuito ${lineLabel}`,
        locationNumber,
        replacementPumpSap: replacementPump?.sap ?? null,
        recommendedAction,
        decision: "pending",
        responseComment: "",
        respondedAt: null,
      };
      setOperationalAlerts((currentAlerts) => [...currentAlerts, event]);
      setOperationalEvents((currentEvents) => [...currentEvents, event]);
      setIsFailureSimulationPending(false);
      setLayoutNotice(
        `ALERTA: bomba ${affectedPump.sap} OFFLINE en ${lineLabel}.`,
      );
    }, 2200);
  }

  function handleResolveOperationalAction(
    alertId: string,
    decision: Exclude<OperationalActionDecision, "pending">,
    comment: string,
  ) {
    const operationalAlert = operationalAlerts.find((alert) => alert.id === alertId);

    if (!operationalAlert || operationalAlert.decision !== "pending") {
      return;
    }

    const respondedAt = new Date().toISOString();
    const resolvedEvent: OperationalEvent = {
      ...operationalAlert,
      decision,
      responseComment: comment,
      respondedAt,
    };

    setInterstagePlan((currentPlan) => ({
      ...currentPlan,
      tasks: [
        ...currentPlan.tasks,
        {
          id: createEntityId("interstage-task"),
          department: operationalAlert.department.toLowerCase() as "pe" | "iem",
          area: operationalAlert.manifoldLabel,
          pumpSap: operationalAlert.pumpSap,
          action: operationalAlert.recommendedAction,
          board: "",
          boardPosition: "",
          crew: `${operationalAlert.department} / Operación`,
          detail: `Evento OFFLINE. Motivo: ${operationalAlert.offlineReason}. Resultado: ${
            decision === "ok" ? "OK" : "No se puede realizar"
          }. Comentario: ${comment}.`,
          estimatedMinutes: 0,
          completed: false,
          createdAt: new Date().toISOString(),
        },
      ],
      updatedAt: new Date().toISOString(),
    }));
    setOperationalAlerts((currentAlerts) =>
      currentAlerts.map((alert) =>
        alert.id === alertId ? resolvedEvent : alert,
      ),
    );
    setOperationalEvents((currentEvents) =>
      currentEvents.map((event) => (event.id === alertId ? resolvedEvent : event)),
    );
    setLayoutNotice(
      `Respuesta registrada para bomba ${operationalAlert.pumpSap}: ${
        decision === "ok" ? "OK" : "No se puede realizar"
      }.`,
    );
  }

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={rectIntersection}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      onDragCancel={() => setActiveDragId(null)}
    >
      <div className="min-h-screen">
        <main className="mx-auto flex min-h-screen w-full max-w-[1920px] flex-col gap-5 px-4 py-4 md:px-6 md:py-6 xl:px-8">
          <ControlHeader
            selectedSet={selectedSet}
            totalInSet={stats.totalInSet}
            operativeInSetCount={stats.operativeInSetCount}
            operativeOutOfSetCount={stats.operativeOutOfSetCount}
            nonOperativeInSetCount={stats.nonOperativeInSetCount}
            nonOperativeOutOfSetCount={stats.nonOperativeOutOfSetCount}
            dgbInSetCount={stats.dgbInSetCount}
            nonDgbInSetCount={stats.nonDgbInSetCount}
            substitutingDgbInSetCount={stats.substitutingDgbInSetCount}
            nonSubstitutingDgbInSetCount={stats.nonSubstitutingDgbInSetCount}
            dgbSubstitutionPercentage={stats.dgbSubstitutionPercentage}
            stageContext={stageContext}
            onSetChange={setSelectedSet}
            onStageContextChange={setStageContext}
            onOpenAddPump={() => {
              setAddPumpTarget(null);
              setIsAddPumpOpen(true);
            }}
            onOpenAddManifold={() => setIsAddManifoldOpen(true)}
            onSaveLayout={handleSaveLayout}
            onClearLayout={handleClearLayout}
            onDownloadExcel={() => {
              void handleDownloadExcel();
            }}
            onOpenCapture={() => setIsCaptureOpen(true)}
            onSimulatePumpFailure={handleSimulatePumpFailure}
            onToggleFullscreen={handleToggleFullscreen}
            isFailureSimulationPending={isFailureSimulationPending}
            isExporting={isExporting}
            isFullscreen={isFullscreen}
          />

          <InterstagePlanner
            history={interstageHistory}
            plan={interstagePlan}
            pumps={pumps}
            selectedSet={selectedSet}
            onHistoryAdd={(record) =>
              setInterstageHistory((currentHistory) => [
                record,
                ...currentHistory,
              ].slice(0, 80))
            }
            onPlanChange={setInterstagePlan}
            onPlanReset={resetInterstagePlan}
          />

          <LayoutWorkspace
            pumps={pumps}
            manifolds={manifolds}
            notice={layoutNotice}
            selectedPumpId={selectedPumpId}
            slotActuators={slotActuators}
            onAddPumpToSlot={(target) => {
              setAddPumpTarget(target);
              setIsAddPumpOpen(true);
            }}
            onEditManifold={setSelectedManifoldId}
            onSelectPump={setSelectedPumpId}
            onSlotActuatorChange={handleSlotActuatorChange}
          />

          <PumpReserve
            pumps={benchPumps}
            selectedPumpId={selectedPumpId}
            onSelectPump={setSelectedPumpId}
          />

          <footer
            aria-label={`Acerca de ${APP_BRAND_NAME}`}
            className="flex flex-col gap-2 rounded-[1.5rem] border border-slate-800/80 bg-slate-950/35 px-5 py-4 text-slate-400 md:flex-row md:items-center md:justify-between"
          >
            <div>
              <p className="text-[0.68rem] font-semibold uppercase tracking-[0.28em] text-slate-500">
                Acerca de {APP_BRAND_NAME}
              </p>
              <p className="mt-1 text-sm font-semibold text-slate-300">
                {APP_AUTHOR_CREDIT}
              </p>
            </div>
            <p className="text-xs font-semibold tracking-[0.16em]">
              {APP_VERSION_LABEL}
            </p>
          </footer>

          <PumpEditModal
            pump={selectedPump}
            onClose={() => setSelectedPumpId(null)}
            onDelete={handleDeletePump}
            onSave={handleSavePump}
          />

          <ManifoldEditModal
            manifold={selectedManifold}
            onClose={() => setSelectedManifoldId(null)}
            onSave={handleSaveManifold}
          />

          <AddPumpModal
            destinationMessage={
              addPumpTarget
                ? `La bomba nueva se ubicara directamente en el slot ${addPumpTarget.position} del lado ${
                    addPumpTarget.side === "left" ? "izquierdo" : "derecho"
                  }.`
                : null
            }
            isOpen={isAddPumpOpen}
            onClose={() => {
              setAddPumpTarget(null);
              setIsAddPumpOpen(false);
            }}
            onAddPump={handleAddPump}
          />

          <AddManifoldModal
            isOpen={isAddManifoldOpen}
            onClose={() => setIsAddManifoldOpen(false)}
            onAddManifold={handleAddManifold}
          />

          {isCaptureOpen ? (
            <CaptureLayoutView
              manifolds={manifolds}
              pumps={pumps}
              selectedSet={selectedSet}
              slotActuators={slotActuators}
              stageContext={stageContext}
              onClose={() => setIsCaptureOpen(false)}
            />
          ) : null}

          <OperationalAlertModal
            alerts={operationalAlerts}
            onClose={(alertId) =>
              setOperationalAlerts((currentAlerts) =>
                currentAlerts.filter((alert) => alert.id !== alertId),
              )
            }
            onResolve={handleResolveOperationalAction}
          />
        </main>
      </div>

      <DragOverlay adjustScale={false}>
        {activePump ? (
          <div className="w-[24rem] max-w-[90vw] opacity-95">
            <PumpUnitCard
              pump={activePump}
              onSelect={() => undefined}
              draggable={false}
              isOverlay
            />
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}
