import { APP_BRAND_NAME } from "../appIdentity";
import {
  getNonOperationalReasonLabel,
  isPumpSetMovement,
  Manifold,
  Pump,
  PUMP_SET_MOVEMENT_META,
  SetNumber,
  WellStageContext,
} from "../models";
import { createSlotActuatorKey, getPumpStats, SlotActuatorMap } from "./layoutState";

type ExportCaptureLayoutPngInput = {
  manifolds: Manifold[];
  pumps: Pump[];
  selectedSet: SetNumber;
  slotActuators: SlotActuatorMap;
  stageContext: WellStageContext;
};

type Point = {
  x: number;
  y: number;
};

const CAPTURE_WIDTH = 1080;
const CAPTURE_HEIGHT = 1920;
const CLEAN_COLOR = "#7FB3C8";
const DIRTY_COLOR = "#8B6A4A";

function escapeXml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function truncate(value: string, maxLength: number) {
  return value.length > maxLength ? `${value.slice(0, maxLength - 1)}...` : value;
}

function wrapText(value: string, maxLength: number, maxLines: number) {
  const words = value.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let currentLine = "";

  words.forEach((word) => {
    const candidate = currentLine ? `${currentLine} ${word}` : word;

    if (candidate.length <= maxLength) {
      currentLine = candidate;
      return;
    }

    if (currentLine) {
      lines.push(currentLine);
    }
    currentLine = word;
  });

  if (currentLine) {
    lines.push(currentLine);
  }

  if (lines.length <= maxLines) {
    return lines;
  }

  const visibleLines = lines.slice(0, maxLines);
  visibleLines[maxLines - 1] = truncate(`${visibleLines[maxLines - 1]}...`, maxLength);

  return visibleLines;
}

function createFileSlug(value: string) {
  const slug = value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .toLowerCase();

  return slug || "layout";
}

function createLocalTimestamp(value: Date) {
  const pad = (entry: number) => String(entry).padStart(2, "0");

  return [
    value.getFullYear(),
    pad(value.getMonth() + 1),
    pad(value.getDate()),
    pad(value.getHours()),
    pad(value.getMinutes()),
  ].join("");
}

function getModeLabel(stageContext: WellStageContext) {
  return stageContext.mode === "dual-simul" ? "Dual / Simul" : "Zipper";
}

function buildStageLabel(stageContext: WellStageContext) {
  const primary = [
    stageContext.primary.well.trim() ? `Pozo ${stageContext.primary.well.trim()}` : "",
    stageContext.primary.stage.trim() ? `Etapa ${stageContext.primary.stage.trim()}` : "",
  ]
    .filter(Boolean)
    .join(" | ");
  const secondary =
    stageContext.mode === "dual-simul"
      ? [
          stageContext.secondary.well.trim()
            ? `Pozo ${stageContext.secondary.well.trim()}`
            : "",
          stageContext.secondary.stage.trim()
            ? `Etapa ${stageContext.secondary.stage.trim()}`
            : "",
        ]
          .filter(Boolean)
          .join(" | ")
      : "";
  const wells = [primary, secondary].filter(Boolean).join(" / ");

  return wells || "Pozo y etapa sin cargar";
}

function svgRect(
  { x, y }: Point,
  width: number,
  height: number,
  options: {
    className?: string;
    dash?: boolean;
    fill?: string;
    radius?: number;
    stroke?: string;
    strokeWidth?: number;
  } = {},
) {
  const radius = options.radius ?? 18;
  const dash = options.dash ? ' stroke-dasharray="10 8"' : "";
  const className = options.className ? ` class="${options.className}"` : "";
  const fill = options.fill ? ` fill="${options.fill}"` : "";
  const stroke = options.stroke ? ` stroke="${options.stroke}"` : "";
  const strokeWidth = options.strokeWidth ? ` stroke-width="${options.strokeWidth}"` : "";

  return `<rect${className} x="${x}" y="${y}" width="${width}" height="${height}" rx="${radius}"${fill}${stroke}${strokeWidth}${dash}/>`;
}

function svgText(
  value: string,
  { x, y }: Point,
  options: {
    anchor?: "start" | "middle" | "end";
    className?: string;
    color?: string;
    size?: number;
    weight?: number;
  } = {},
) {
  const anchor = options.anchor ?? "start";
  const color = options.color ? ` fill="${options.color}"` : "";
  const weight = options.weight ? ` font-weight="${options.weight}"` : "";
  const size = options.size ? ` font-size="${options.size}"` : "";
  const className = options.className ? ` class="${options.className}"` : "";

  return `<text${className} x="${x}" y="${y}" text-anchor="${anchor}"${color}${weight}${size}>${escapeXml(value)}</text>`;
}

function getPumpAtSlot(
  pumps: Pump[],
  manifoldId: string,
  side: "left" | "right",
  position: number,
) {
  return (
    pumps.find(
      (pump) =>
        pump.side === side &&
        pump.manifoldId === manifoldId &&
        pump.position === position,
    ) ?? null
  );
}

function getPumpMovementLabel(pump: Pump) {
  return pump.setMovementEdited === true && isPumpSetMovement(pump.setMovement)
    ? PUMP_SET_MOVEMENT_META[pump.setMovement].label
    : "";
}

function buildPumpPdsLine(pump: Pump) {
  return `P${pump.signals.p} D${pump.signals.d} S${pump.signals.s}`;
}

function buildCommentsLine(pumps: Pump[]) {
  return pumps
    .map((pump) => {
      const movementComment = pump.setMovementComment.trim();
      const movementLabel = getPumpMovementLabel(pump);
      const nonOperationalReason =
        pump.operationState === "non-operative" && pump.nonOperationalReason
          ? `NO OP ${getNonOperationalReasonLabel(pump.nonOperationalReason)}`
          : "";
      const comment = [nonOperationalReason, movementComment].filter(Boolean).join(": ");

      if (!comment && !movementLabel) {
        return "";
      }

      return `${pump.sap}${movementLabel ? ` ${movementLabel}` : ""}${comment ? `: ${comment}` : ""}`;
    })
    .filter(Boolean)
    .join(" | ");
}

function drawPumpCard(
  pump: Pump | null,
  point: Point,
  width: number,
  height: number,
  options: {
    actuatorValue?: string;
    connectionColor: string;
    emptyLabel: string;
    side?: "left" | "right";
    variant?: "slot" | "reserve";
  },
) {
  const parts: string[] = [];
  const isReserve = options.variant === "reserve";
  const isSmall = height < 42;
  const sapSize = isReserve ? (isSmall ? 16 : 22) : isSmall ? 20 : height < 54 ? 25 : 31;
  const labelSize = isSmall ? 12 : 14;
  const pdsSize = isReserve ? (isSmall ? 11 : 14) : isSmall ? 12 : height < 54 ? 14 : 16;

  if (!pump) {
    parts.push(
      svgRect(point, width, height, {
        dash: true,
        fill: "rgba(15,23,42,0.58)",
        radius: 12,
        stroke: "rgba(148,163,184,0.38)",
      }),
    );
    parts.push(
      svgText(options.emptyLabel, { x: point.x + width / 2, y: point.y + height / 2 + 5 }, {
        anchor: "middle",
        color: "#94A3B8",
        size: labelSize,
        weight: 700,
      }),
    );
    return parts.join("");
  }

  const isOperative = pump.operationState === "operative";
  const stroke = isOperative ? "rgba(52,211,153,0.62)" : "rgba(248,113,113,0.72)";
  const pdsLine = buildPumpPdsLine(pump);

  parts.push(
    svgRect(point, width, height, {
      fill: "#081527",
      radius: 12,
      stroke,
      strokeWidth: 2,
    }),
  );
  parts.push(
    `<line x1="${point.x + 10}" y1="${point.y + height - 10}" x2="${
      point.x + width - 10
    }" y2="${point.y + height - 10}" stroke="${options.connectionColor}" stroke-width="3" opacity="0.4"/>`,
  );

  const rightTextX = point.x + width - 12;
  if (options.actuatorValue) {
    parts.push(
      svgText(options.actuatorValue, { x: rightTextX, y: point.y + 18 }, {
        anchor: "end",
        color: "#F8FAFC",
        size: labelSize,
        weight: 900,
      }),
    );
  }
  parts.push(
    svgText(pump.sap, {
      x: isReserve ? point.x + width / 2 : point.x + width * 0.34,
      y: point.y + (isReserve ? height * 0.38 : height / 2) + sapSize / 3,
    }, {
      anchor: "middle",
      color: "#F8FAFC",
      size: sapSize,
      weight: 900,
    }),
  );
  parts.push(
    svgText(
      truncate(pdsLine.toUpperCase(), 32),
      {
        x: isReserve ? point.x + width / 2 : rightTextX,
        y: point.y + (isReserve ? height - 18 : height / 2 + pdsSize / 3),
      },
      {
        anchor: isReserve ? "middle" : "end",
        className: "mono",
        color: "#CBD5E1",
        size: pdsSize,
        weight: 900,
      },
    ),
  );

  return parts.join("");
}

function buildCaptureSvg({
  manifolds,
  pumps,
  selectedSet,
  slotActuators,
  stageContext,
}: ExportCaptureLayoutPngInput) {
  const stats = getPumpStats(pumps);
  const benchPumps = pumps
    .filter((pump) => pump.side === "bench")
    .sort((firstPump, secondPump) => firstPump.row - secondPump.row);
  const reserveCommentsLine = buildCommentsLine(benchPumps);
  const reserveCommentLines = reserveCommentsLine
    ? wrapText(`Comentarios: ${reserveCommentsLine}`, 104, 2)
    : [];
  const reserveRowsForHeight = Math.max(1, Math.ceil((benchPumps.length || 1) / 4));
  const headerHeight = 150;
  const reserveHeight = Math.max(
    180 + reserveCommentLines.length * 18,
    Math.min(300, 90 + reserveRowsForHeight * 78 + reserveCommentLines.length * 18),
  );
  const margin = 34;
  const gap = 18;
  const mainY = headerHeight + margin;
  const mainHeight = CAPTURE_HEIGHT - headerHeight - reserveHeight - margin * 3;
  const manifoldHeight =
    manifolds.length > 0
      ? (mainHeight - gap * Math.max(manifolds.length - 1, 0)) / manifolds.length
      : mainHeight;
  const body: string[] = [];

  body.push(`<svg xmlns="http://www.w3.org/2000/svg" width="${CAPTURE_WIDTH}" height="${CAPTURE_HEIGHT}" viewBox="0 0 ${CAPTURE_WIDTH} ${CAPTURE_HEIGHT}">`);
  body.push(`<defs><linearGradient id="bg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#0F172A"/><stop offset="0.48" stop-color="#08111F"/><stop offset="1" stop-color="#020617"/></linearGradient></defs>`);
  body.push(`<rect width="100%" height="100%" fill="url(#bg)"/>`);
  body.push(`<style>text{font-family:Bahnschrift,Segoe UI,Arial,sans-serif;letter-spacing:0}.mono{font-family:Consolas,Menlo,monospace}</style>`);
  body.push(svgRect({ x: margin, y: margin }, CAPTURE_WIDTH - margin * 2, headerHeight - 20, {
    fill: "rgba(15,23,42,0.84)",
    radius: 24,
    stroke: "rgba(127,179,200,0.38)",
  }));
  body.push(svgText(APP_BRAND_NAME, { x: margin + 28, y: margin + 48 }, {
    color: "#F8FAFC",
    size: 42,
    weight: 900,
  }));
  body.push(svgText(stageContext.pad.trim() || "Pad sin cargar", { x: margin + 28, y: margin + 88 }, {
    color: "#DBE8EE",
    size: 24,
    weight: 800,
  }));
  body.push(svgText(buildStageLabel(stageContext), { x: margin + 28, y: margin + 120 }, {
    color: "#CBD5E1",
    size: 21,
    weight: 700,
  }));
  body.push(svgText(`SET ${selectedSet}`, { x: CAPTURE_WIDTH - margin - 28, y: margin + 48 }, {
    anchor: "end",
    color: "#F8FAFC",
    size: 36,
    weight: 900,
  }));
  body.push(svgText(getModeLabel(stageContext), { x: CAPTURE_WIDTH - margin - 28, y: margin + 84 }, {
    anchor: "end",
    color: "#DBE8EE",
    size: 22,
    weight: 800,
  }));
  body.push(svgText(`En set ${stats.totalInSet} | OP ${stats.operativeInSetCount} | NO OP ${stats.nonOperativeInSetCount} | DGB ${stats.dgbSubstitutionPercentage}%`, { x: CAPTURE_WIDTH - margin - 28, y: margin + 118 }, {
    anchor: "end",
    color: "#CBD5E1",
    size: 18,
    weight: 700,
  }));

  manifolds.forEach((manifold, manifoldIndex) => {
    const y = mainY + manifoldIndex * (manifoldHeight + gap);
    const assignedPumps = pumps.filter(
      (pump) => pump.side !== "bench" && pump.manifoldId === manifold.id,
    );
    const commentsLine = buildCommentsLine(assignedPumps);
    const commentLines = commentsLine ? wrapText(`Comentarios: ${commentsLine}`, 104, 2) : [];
    const titleHeight = commentLines.length > 0 ? 48 + commentLines.length * 20 : 50;
    const centerWidth = 94;
    const sideWidth = (CAPTURE_WIDTH - margin * 2 - centerWidth) / 2;
    const leftX = margin;
    const centerX = leftX + sideWidth;
    const rightX = centerX + centerWidth;
    const slotsY = y + titleHeight + 8;
    const slotsHeight = manifoldHeight - titleHeight - 8;
    const rowCount = Math.max(manifold.pumpsPerSide, 1);
    const rowHeight = slotsHeight / rowCount;
    const connectionColor = manifold.type === "clean" ? CLEAN_COLOR : DIRTY_COLOR;
    const titleColor = manifold.type === "clean" ? "#DBE8EE" : "#F0E2D1";
    const titleFill = manifold.type === "clean" ? "rgba(127,179,200,0.12)" : "rgba(139,106,74,0.16)";

    body.push(svgRect({ x: margin, y }, CAPTURE_WIDTH - margin * 2, manifoldHeight, {
      fill: "rgba(15,23,42,0.5)",
      radius: 22,
      stroke: "rgba(148,163,184,0.28)",
    }));
    body.push(svgRect({ x: margin + 14, y: y + 12 }, CAPTURE_WIDTH - margin * 2 - 28, commentLines.length > 0 ? 38 + commentLines.length * 20 : 36, {
      fill: titleFill,
      radius: 14,
      stroke: "rgba(148,163,184,0.22)",
    }));
    body.push(svgText(`${manifold.label} | ${manifold.type === "clean" ? "Limpio" : "Sucio"}`, { x: margin + 32, y: y + 37 }, {
      color: titleColor,
      size: 22,
      weight: 900,
    }));
    body.push(svgText(`${assignedPumps.length} bombas | ${manifold.pumpsPerSide} slots por lado`, { x: CAPTURE_WIDTH - margin - 32, y: y + 37 }, {
      anchor: "end",
      color: "#CBD5E1",
      size: 17,
      weight: 800,
    }));
    commentLines.forEach((line, lineIndex) => {
      body.push(svgText(line, { x: margin + 32, y: y + 60 + lineIndex * 18 }, {
        color: "#FDE68A",
        size: 15,
        weight: 800,
      }));
    });
    body.push(svgRect({ x: centerX + centerWidth / 2 - 16, y: slotsY }, 32, slotsHeight, {
      fill: "#020617",
      radius: 16,
      stroke: "rgba(148,163,184,0.42)",
    }));
    body.push(`<line x1="${centerX + centerWidth / 2}" y1="${slotsY + 12}" x2="${centerX + centerWidth / 2}" y2="${slotsY + slotsHeight - 12}" stroke="${connectionColor}" stroke-width="5" opacity="0.52"/>`);

    for (let position = 1; position <= rowCount; position += 1) {
      const rowY = slotsY + (position - 1) * rowHeight + 2;
      const cardHeight = Math.max(22, rowHeight - 4);
      const leftPump = getPumpAtSlot(pumps, manifold.id, "left", position);
      const rightPump = getPumpAtSlot(pumps, manifold.id, "right", position);
      const leftActuator =
        slotActuators[createSlotActuatorKey({ manifoldId: manifold.id, side: "left", position })] ??
        "";
      const rightActuator =
        slotActuators[createSlotActuatorKey({ manifoldId: manifold.id, side: "right", position })] ??
        "";

      body.push(
        drawPumpCard(leftPump, { x: leftX + 6, y: rowY }, sideWidth - 16, cardHeight, {
          actuatorValue: leftActuator,
          connectionColor,
          emptyLabel: `Slot ${position}`,
          side: "left",
        }),
      );
      body.push(
        drawPumpCard(rightPump, { x: rightX + 10, y: rowY }, sideWidth - 16, cardHeight, {
          actuatorValue: rightActuator,
          connectionColor,
          emptyLabel: `Slot ${position}`,
          side: "right",
        }),
      );
    }
  });

  const reserveY = CAPTURE_HEIGHT - reserveHeight - margin;
  body.push(svgRect({ x: margin, y: reserveY }, CAPTURE_WIDTH - margin * 2, reserveHeight, {
    fill: "rgba(15,23,42,0.62)",
    radius: 22,
    stroke: "rgba(148,163,184,0.28)",
  }));
  body.push(svgText(`Fuera del set / reserva (${benchPumps.length})`, { x: margin + 28, y: reserveY + 40 }, {
    color: "#F8FAFC",
    size: 22,
    weight: 900,
  }));
  reserveCommentLines.forEach((line, lineIndex) => {
    body.push(svgText(line, { x: margin + 28, y: reserveY + 62 + lineIndex * 18 }, {
      color: "#FDE68A",
      size: 15,
      weight: 800,
    }));
  });

  const reserveCols = Math.max(1, Math.min(benchPumps.length || 1, 4));
  const reserveRows = Math.max(1, Math.ceil((benchPumps.length || 1) / reserveCols));
  const reserveGap = 12;
  const reserveGridY =
    reserveY + (reserveCommentLines.length > 0 ? 66 + reserveCommentLines.length * 18 : 62);
  const reserveCardW =
    (CAPTURE_WIDTH - margin * 2 - 28 - reserveGap * (reserveCols - 1)) / reserveCols;
  const reserveCardH =
    (reserveHeight -
      (reserveCommentLines.length > 0 ? 86 + reserveCommentLines.length * 18 : 82) -
      reserveGap * (reserveRows - 1)) /
    reserveRows;

  if (benchPumps.length === 0) {
    body.push(svgText("Sin bombas fuera del set", { x: CAPTURE_WIDTH / 2, y: reserveY + reserveHeight / 2 + 14 }, {
      anchor: "middle",
      color: "#94A3B8",
      size: 24,
      weight: 800,
    }));
  } else {
    benchPumps.forEach((pump, index) => {
      const col = index % reserveCols;
      const row = Math.floor(index / reserveCols);
      const x = margin + 14 + col * (reserveCardW + reserveGap);
      const y = reserveGridY + row * (reserveCardH + reserveGap);

      body.push(
        drawPumpCard(pump, { x, y }, reserveCardW, reserveCardH, {
          connectionColor: "#64748B",
          emptyLabel: "",
          variant: "reserve",
        }),
      );
    });
  }

  body.push("</svg>");
  return body.join("");
}

export async function downloadCaptureLayoutPng(input: ExportCaptureLayoutPngInput) {
  const svg = buildCaptureSvg(input);
  const { selectedSet, stageContext } = input;
  const svgBlob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
  const svgUrl = URL.createObjectURL(svgBlob);
  const image = new Image();

  try {
    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve();
      image.onerror = () => reject(new Error("No se pudo preparar la captura."));
      image.src = svgUrl;
    });

    const canvas = document.createElement("canvas");
    canvas.width = CAPTURE_WIDTH;
    canvas.height = CAPTURE_HEIGHT;

    const context = canvas.getContext("2d");

    if (!context) {
      throw new Error("No se pudo crear el canvas de captura.");
    }

    context.drawImage(image, 0, 0);

    const pngBlob = await new Promise<Blob | null>((resolve) => {
      canvas.toBlob(resolve, "image/png", 1);
    });

    if (!pngBlob) {
      throw new Error("No se pudo generar el PNG.");
    }

    const fileDate = createLocalTimestamp(new Date());
    const fileName = `LUCTIV_captura_${createFileSlug(
      stageContext.pad.trim() || stageContext.primary.well || `set-${selectedSet}`,
    )}_${fileDate}.png`;
    const pngUrl = URL.createObjectURL(pngBlob);
    const link = document.createElement("a");
    link.href = pngUrl;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.setTimeout(() => URL.revokeObjectURL(pngUrl), 1000);

    return fileName;
  } finally {
    URL.revokeObjectURL(svgUrl);
  }
}
