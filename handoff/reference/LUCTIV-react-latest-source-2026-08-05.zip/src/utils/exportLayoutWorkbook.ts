import writeXlsxFile, { Cell, SheetData } from "write-excel-file/browser";
import { APP_AUTHOR_NAME, APP_BRAND_NAME, APP_VERSION } from "../appIdentity";
import {
  getNonOperationalReasonLabel,
  InterstageHistoryRecord,
  InterstagePlan,
  InterstageTask,
  InterstageTaskDepartment,
  isPumpSetMovement,
  Manifold,
  OperationalEvent,
  Pump,
  PUMP_SET_MOVEMENT_META,
  SetNumber,
  SIDE_LABELS,
  WellStageContext,
} from "../models";
import { createSlotActuatorKey, getPumpStats, SlotActuatorMap } from "./layoutState";

type ExportLayoutWorkbookInput = {
  interstageHistory: InterstageHistoryRecord[];
  interstagePlan: InterstagePlan;
  manifolds: Manifold[];
  operationalEvents: OperationalEvent[];
  pumps: Pump[];
  selectedSet: SetNumber;
  slotActuators: SlotActuatorMap;
  stageContext: WellStageContext;
};

type RecommendationRow = [string, string, string, string];

type InterstageExportMetrics = {
  completedTaskCount: number;
  criticalTaskMinutes: number;
  elapsedSeconds: number;
  heuristicMinutes: number;
  projectedMinutes: number;
  setAverageSeconds: number | null;
  setHistoryCount: number;
  signature: string;
  similarAverageSeconds: number | null;
  similarHistoryCount: number;
  taskCounts: Record<InterstageTaskDepartment, number>;
};

const BASE_OPERATION_MINUTES = 5;

const INTERSTAGE_DEPARTMENT_LABELS: Record<InterstageTaskDepartment, string> = {
  pe: "Mantenimiento PE",
  iem: "Mantenimiento IEM",
};

const INTERSTAGE_STATUS_LABELS: Record<InterstagePlan["status"], string> = {
  planning: "Planeando",
  running: "En curso",
  completed: "Cerrada",
};

const RECOMMENDED_FIELDS: RecommendationRow[] = [
  ["Identificacion", "Fecha y hora de captura", "Agregar por snapshot/evento", "Permite construir series temporales y anticipar fallas."],
  ["Identificacion", "Pad, pozo y etapa", "Disponible ahora", "Segmenta resultados por trabajo y permite comparar etapas."],
  ["Configuracion", "Set, SAP, manifold, lado y slot", "Disponible ahora", "Reconstruye la configuracion fisica de cada bomba."],
  ["Configuracion", "Actuadores asignados por slot", "Disponible ahora", "Registra capacidad asignada incluso cuando no hay bomba en el slot."],
  ["Estado", "Operativa, motivo no operativa y error DGB", "Disponible ahora", "Define eventos de indisponibilidad y causas."],
  ["Estado", "Movimiento de bomba Entra/Sale/MTTO y comentarios", "Disponible ahora", "Diferencia equipos que ingresan, salen o pasan a mantenimiento durante cambios operativos."],
  ["Mantenimiento", "Plan manual PE/IEM para la proxima entre etapa", "Disponible ahora", "Documenta tarea, bomba, zona, tablero, personal, detalle y estimacion no acumulativa."],
  ["Mantenimiento", "Historico de entre etapas cerradas", "Disponible ahora", "Permite comparar duraciones reales por SET y firma de tareas."],
  ["DGB", "Tiene DGB y porcentaje de sustitucion", "Disponible ahora", "Mide el resultado principal de sustitucion."],
  ["Senales bomba", "P, D y S", "Disponible ahora", "Variables de condicion de la bomba en el snapshot."],
  ["Tratamiento", "Caudal total y caudal asignado a cada pozo", "Agregar", "Explica demanda real y distribucion en Dual/Simul."],
  ["Tratamiento", "Presion de tratamiento, presion de linea y setpoints", "Agregar", "Captura condiciones que preceden degradacion."],
  ["Fluido", "Tipo de fluido, densidad, concentracion de arena y aditivos", "Agregar", "Ayuda a diferenciar desgaste por receta de bombeo."],
  ["Equipo", "RPM, carga, temperaturas, vibracion y alarmas", "Agregar", "Mejora la prediccion temprana de falla."],
  ["Mantenimiento", "Horas acumuladas, reparacion previa y componentes cambiados", "Agregar", "Relaciona degradacion con historial tecnico del activo."],
  ["Objetivo modelo", "Falla o perdida de sustitucion en los proximos N minutos", "Definir", "Evita entrenar sin un objetivo predictivo medible."],
];

function headerCell(value: string): Cell {
  return {
    value,
    fontWeight: "bold",
    textColor: "#FFFFFF",
    backgroundColor: "#132238",
    borderColor: "#7FB3C8",
    borderStyle: "thin",
    align: "center",
    alignVertical: "center",
    wrap: true,
    height: 34,
  };
}

function titleCell(value: string, span: number): Cell {
  return {
    value,
    columnSpan: span,
    fontSize: 16,
    fontWeight: "bold",
    textColor: "#FFFFFF",
    backgroundColor: "#24475A",
    alignVertical: "center",
    height: 32,
  };
}

function dateCell(value: Date): Cell {
  return {
    value,
    type: Date,
    format: "dd/mm/yyyy hh:mm:ss",
  };
}

function dateOrEmptyCell(value: string | null): Cell | string {
  if (!value) {
    return "";
  }

  const parsedValue = Date.parse(value);

  if (!Number.isFinite(parsedValue)) {
    return "";
  }

  return dateCell(new Date(parsedValue));
}

function wrappedTextCell(value: string, span = 1): Cell {
  return {
    value,
    columnSpan: span,
    wrap: true,
    alignVertical: "top",
    height: 120,
  };
}

function metricCell(value: string): Cell {
  return {
    value,
    fontWeight: "bold",
    textColor: "#DBE8EE",
    backgroundColor: "#1E3348",
    borderColor: "#7FB3C8",
    borderStyle: "thin",
    wrap: true,
  };
}

function createFileSlug(value: string) {
  const slug = value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .toLowerCase();

  return slug || "layout";
}

function toYesNo(value: boolean) {
  return value ? "Si" : "No";
}

function toContextValue(value: string) {
  return value.trim() || "Sin cargar";
}

function toOptionalContextValue(value: string) {
  return value.trim() || "";
}

function formatMinutes(value: number | null) {
  if (value === null || !Number.isFinite(value)) {
    return "";
  }

  const roundedValue = Math.round(value * 10) / 10;

  return Number.isInteger(roundedValue) ? String(roundedValue) : roundedValue.toFixed(1);
}

function formatClock(totalSeconds: number) {
  const safeSeconds = Math.max(0, Math.floor(totalSeconds));
  const minutes = Math.floor(safeSeconds / 60);
  const seconds = safeSeconds % 60;

  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function getWellStageModeLabel(stageContext: WellStageContext) {
  return stageContext.mode === "dual-simul" ? "Dual / Simul" : "Zipper";
}

function buildStageLabel(stageContext: WellStageContext) {
  const entries = [
    stageContext.primary,
    ...(stageContext.mode === "dual-simul" ? [stageContext.secondary] : []),
  ]
    .map((entry) => {
      const well = entry.well.trim();
      const stage = entry.stage.trim();

      if (well && stage) {
        return `${well} etapa ${stage}`;
      }

      return well || (stage ? `etapa ${stage}` : "");
    })
    .filter(Boolean);

  const pad = stageContext.pad.trim();
  const stageLabel = entries.length > 0 ? entries.join(" / ") : "sin pozo-etapa";

  return pad ? `${pad} - ${stageLabel}` : stageLabel;
}

function buildTaskSignature(tasks: InterstageTask[]) {
  if (tasks.length === 0) {
    return "sin-tareas";
  }

  const actionCounts = new Map<string, number>();

  tasks.forEach((task) => {
    const key = `${task.department}:${task.action.trim().toLowerCase() || "sin-accion"}`;
    actionCounts.set(key, (actionCounts.get(key) ?? 0) + 1);
  });

  return Array.from(actionCounts.entries())
    .sort(([firstKey], [secondKey]) => firstKey.localeCompare(secondKey))
    .map(([key, count]) => `${key}x${count}`)
    .join("|");
}

function buildInterstageTaskText(task: InterstageTask) {
  const pumpLabel = task.pumpSap.trim() || "Bomba s/d";
  const actionLabel = task.action.trim() || "tarea";
  const boardParts = [
    task.board.trim() ? `tablero ${task.board.trim()}` : "",
    task.boardPosition.trim() ? `posicion ${task.boardPosition.trim()}` : "",
  ].filter(Boolean);
  const boardText = boardParts.length > 0 ? ` (${boardParts.join(", ")})` : "";
  const lines = [`${pumpLabel}: ${actionLabel}${boardText}`];

  if (task.crew.trim()) {
    lines.push(task.crew.trim());
  }

  if (task.detail.trim()) {
    lines.push(task.detail.trim());
  }

  return lines.join("\n");
}

function buildInterstageMessage(plan: InterstagePlan) {
  const header = `Chicos, faltan ${plan.stageLeadMinutes} minutos para que finalice la etapa. Paso movimientos:`;
  const nextStageLabel = buildStageLabel(plan.nextStageContext);
  const peTasks = plan.tasks.filter((task) => task.department === "pe");
  const iemTasks = plan.tasks.filter((task) => task.department === "iem");
  const sections: string[] = [];

  if (nextStageLabel !== "sin pozo-etapa") {
    sections.push(`proxima etapa:\n${nextStageLabel}`);
  }

  if (peTasks.length > 0) {
    const groupedByArea = new Map<string, InterstageTask[]>();

    peTasks.forEach((task) => {
      const area = task.area.trim() || "sin zona definida";
      groupedByArea.set(area, [...(groupedByArea.get(area) ?? []), task]);
    });

    groupedByArea.forEach((tasks, area) => {
      sections.push(`${area}:\n${tasks.map(buildInterstageTaskText).join("\n\n")}`);
    });
  }

  if (iemTasks.length > 0) {
    sections.push(`mantenimiento IEM:\n${iemTasks.map(buildInterstageTaskText).join("\n\n")}`);
  }

  if (sections.length === 0) {
    sections.push("Sin movimientos cargados.");
  }

  if (plan.note.trim()) {
    sections.push(`nota:\n${plan.note.trim()}`);
  }

  return `${header}\n\n${sections.join("\n\n")}`;
}

function calculateInterstageMetrics(
  plan: InterstagePlan,
  history: InterstageHistoryRecord[],
  selectedSet: SetNumber,
): InterstageExportMetrics {
  const signature = buildTaskSignature(plan.tasks);
  const similarHistory = history.filter(
    (record) =>
      record.setNumber === selectedSet &&
      record.signature === signature &&
      record.id !== plan.historyRecordId,
  );
  const setHistory = history.filter(
    (record) => record.setNumber === selectedSet && record.id !== plan.historyRecordId,
  );
  const similarAverageSeconds =
    similarHistory.length > 0
      ? similarHistory.reduce((total, record) => total + record.durationSeconds, 0) /
        similarHistory.length
      : null;
  const setAverageSeconds =
    setHistory.length > 0
      ? setHistory.reduce((total, record) => total + record.durationSeconds, 0) /
        setHistory.length
      : null;
  const criticalTaskMinutes = plan.tasks.reduce(
    (highestEstimate, task) => Math.max(highestEstimate, task.estimatedMinutes),
    0,
  );
  const heuristicMinutes = BASE_OPERATION_MINUTES + criticalTaskMinutes;
  const projectedMinutes =
    similarAverageSeconds !== null ? similarAverageSeconds / 60 : heuristicMinutes;
  const startedMs = plan.startedAt ? Date.parse(plan.startedAt) : null;
  const endedMs = plan.endedAt ? Date.parse(plan.endedAt) : null;
  const elapsedSeconds =
    plan.status === "running" && startedMs !== null && Number.isFinite(startedMs)
      ? Math.max(0, (Date.now() - startedMs) / 1000)
      : plan.status === "completed" &&
          startedMs !== null &&
          endedMs !== null &&
          Number.isFinite(startedMs) &&
          Number.isFinite(endedMs)
        ? Math.max(0, (endedMs - startedMs) / 1000)
        : 0;

  return {
    completedTaskCount: plan.tasks.filter((task) => task.completed).length,
    criticalTaskMinutes,
    elapsedSeconds,
    heuristicMinutes,
    projectedMinutes,
    setAverageSeconds,
    setHistoryCount: setHistory.length,
    signature,
    similarAverageSeconds,
    similarHistoryCount: similarHistory.length,
    taskCounts: {
      pe: plan.tasks.filter((task) => task.department === "pe").length,
      iem: plan.tasks.filter((task) => task.department === "iem").length,
    },
  };
}

function getSetMovementLabel(pump: Pump) {
  if (
    pump.setMovementEdited !== true ||
    !isPumpSetMovement(pump.setMovement)
  ) {
    return "";
  }

  return PUMP_SET_MOVEMENT_META[pump.setMovement].label;
}

function getSetMovementComment(pump: Pump) {
  if (
    pump.setMovementEdited !== true ||
    !isPumpSetMovement(pump.setMovement) ||
    !PUMP_SET_MOVEMENT_META[pump.setMovement].requiresComment
  ) {
    return "";
  }

  return pump.setMovementComment.trim();
}

function getSlotActuatorValue(
  slotActuators: SlotActuatorMap,
  target: {
    manifoldId: string;
    position: number;
    side: "left" | "right";
  },
) {
  return slotActuators[createSlotActuatorKey(target)] ?? "";
}

function createLocalTimestamp(value: Date) {
  const pad = (entry: number) => String(entry).padStart(2, "0");

  return [
    value.getFullYear(),
    pad(value.getMonth() + 1),
    pad(value.getDate()),
    pad(value.getHours()),
    pad(value.getMinutes()),
  ].join("");
}

export async function exportLayoutWorkbook({
  interstageHistory,
  interstagePlan,
  manifolds,
  operationalEvents,
  pumps,
  selectedSet,
  slotActuators,
  stageContext,
}: ExportLayoutWorkbookInput) {
  const exportDate = new Date();
  const stats = getPumpStats(pumps);
  const manifoldById = new Map(manifolds.map((manifold) => [manifold.id, manifold]));
  const secondaryEnabled = stageContext.mode === "dual-simul";
  const modeLabel = secondaryEnabled ? "Dual / Simul" : "Zipper";
  const padLabel = toContextValue(stageContext.pad ?? "");
  const interstageMetrics = calculateInterstageMetrics(
    interstagePlan,
    interstageHistory,
    selectedSet,
  );
  const nextStageContext = interstagePlan.nextStageContext;
  const nextStageSecondaryEnabled = nextStageContext.mode === "dual-simul";
  const nextStageLabel = buildStageLabel(nextStageContext);
  const interstageMessage = buildInterstageMessage(interstagePlan);
  const projectedDelta = interstageMetrics.projectedMinutes - interstagePlan.targetMinutes;

  const summaryData: SheetData = [
    [titleCell(`${APP_BRAND_NAME} - Resumen de pozo y etapa`, 4), null, null, null],
    ["Desarrollado por", APP_AUTHOR_NAME, "Version", APP_VERSION],
    ["Exportado", dateCell(exportDate), "", ""],
    ["SET", selectedSet, "Modalidad", modeLabel],
    ["Pad", padLabel, "", ""],
    ["Pozo 1", toContextValue(stageContext.primary.well), "Etapa 1", toContextValue(stageContext.primary.stage)],
    [
      "Pozo 2",
      secondaryEnabled ? toContextValue(stageContext.secondary.well) : "No aplica",
      "Etapa 2",
      secondaryEnabled ? toContextValue(stageContext.secondary.stage) : "No aplica",
    ],
    [],
    [headerCell("Indicador"), headerCell("Valor")],
    ["Bombas en set", stats.totalInSet],
    ["Operativas en set", stats.operativeInSetCount],
    ["No operativas en set", stats.nonOperativeInSetCount],
    ["Operativas fuera de set", stats.operativeOutOfSetCount],
    ["No operativas fuera de set", stats.nonOperativeOutOfSetCount],
    ["Bombas con DGB", stats.dgbInSetCount],
    ["Bombas sin DGB", stats.nonDgbInSetCount],
    ["Bombas sustituyendo", stats.substitutingDgbInSetCount],
    ["Bombas sin sustituir", stats.nonSubstitutingDgbInSetCount],
    ["Sustitucion DGB (%)", stats.dgbSubstitutionPercentage],
  ];

  const pumpHeaders = [
    "Fecha exportacion",
    "Pad",
    "SET",
    "Modalidad",
    "Pozo 1",
    "Etapa 1",
    "Pozo 2",
    "Etapa 2",
    "SAP",
    "En set",
    "Movimiento set",
    "comentarios",
    "Manifold",
    "Tipo manifold",
    "Lado",
    "Slot",
    "Actuadores asignados",
    "Estado",
    "Motivo no operativa",
    "DGB",
    "Sustitucion (%)",
    "Sustituyendo",
    "Error DGB",
    "P",
    "D",
    "S",
    "Columnas P/D/S",
    "Linea",
  ];
  const pumpData: SheetData = [pumpHeaders.map(headerCell)];

  pumps.forEach((pump) => {
    const manifold = pump.manifoldId ? manifoldById.get(pump.manifoldId) : undefined;
    const inSet = pump.side !== "bench";
    let actuatorValue = "";

    if (pump.side !== "bench" && pump.manifoldId) {
      actuatorValue = getSlotActuatorValue(slotActuators, {
        manifoldId: pump.manifoldId,
        position: pump.position,
        side: pump.side,
      });
    }

    pumpData.push([
      dateCell(exportDate),
      stageContext.pad?.trim() ?? "",
      selectedSet,
      modeLabel,
      stageContext.primary.well.trim(),
      stageContext.primary.stage.trim(),
      secondaryEnabled ? stageContext.secondary.well.trim() : "",
      secondaryEnabled ? stageContext.secondary.stage.trim() : "",
      pump.sap,
      toYesNo(inSet),
      getSetMovementLabel(pump),
      getSetMovementComment(pump),
      manifold?.label ?? "",
      manifold?.type === "clean" ? "Limpio" : manifold?.type === "dirty" ? "Sucio" : "",
      SIDE_LABELS[pump.side],
      inSet ? pump.position : "",
      actuatorValue,
      pump.operationState === "operative" ? "Operativa" : "No operativa",
      pump.nonOperationalReason ? getNonOperationalReasonLabel(pump.nonOperationalReason) : "",
      toYesNo(pump.isDgb === true),
      pump.isDgb === true ? pump.substitutionPercentage : 0,
      toYesNo(pump.isDgb === true && pump.substitutionPercentage > 0),
      pump.substitutionError,
      pump.signals.p,
      pump.signals.d,
      pump.signals.s,
      pump.signalColumnCount === 5 ? 5 : 3,
      pump.connection === "clean"
        ? "Limpio"
        : pump.connection === "dirty"
          ? "Sucio"
          : "Sin linea",
    ]);
  });

  const manifoldData: SheetData = [
    ["Manifold", "Tipo", "Slots por lado", "Bombas asignadas", "Operativas", "No operativas"].map(headerCell),
  ];

  manifolds.forEach((manifold) => {
    const assignedPumps = pumps.filter(
      (pump) => pump.side !== "bench" && pump.manifoldId === manifold.id,
    );

    manifoldData.push([
      manifold.label,
      manifold.type === "clean" ? "Limpio" : "Sucio",
      manifold.pumpsPerSide,
      assignedPumps.length,
      assignedPumps.filter((pump) => pump.operationState === "operative").length,
      assignedPumps.filter((pump) => pump.operationState === "non-operative").length,
    ]);
  });

  const slotData: SheetData = [
    [
      "Manifold",
      "Tipo manifold",
      "Lado",
      "Slot",
      "SAP bomba",
      "Estado bomba",
      "Actuadores asignados",
    ].map(headerCell),
  ];
  const slotSides = ["left", "right"] as const;

  manifolds.forEach((manifold) => {
    slotSides.forEach((side) => {
      for (let position = 1; position <= manifold.pumpsPerSide; position += 1) {
        const slotPump = pumps.find(
          (pump) =>
            pump.side === side &&
            pump.manifoldId === manifold.id &&
            pump.position === position,
        );

        slotData.push([
          manifold.label,
          manifold.type === "clean" ? "Limpio" : "Sucio",
          SIDE_LABELS[side],
          position,
          slotPump?.sap ?? "",
          slotPump
            ? slotPump.operationState === "operative"
              ? "Operativa"
              : "No operativa"
            : "",
          getSlotActuatorValue(slotActuators, {
            manifoldId: manifold.id,
            position,
            side,
          }),
        ]);
      }
    });
  });

  const interstageSummaryData: SheetData = [
    [titleCell(`${APP_BRAND_NAME} - Proxima entre etapa`, 6), null, null, null, null, null],
    ["Exportado", dateCell(exportDate), "SET", selectedSet, "Estado", INTERSTAGE_STATUS_LABELS[interstagePlan.status]],
    [
      "Proxima etapa",
      nextStageLabel,
      "Modalidad",
      getWellStageModeLabel(nextStageContext),
      "Firma tareas",
      interstageMetrics.signature,
    ],
    [
      "Pad",
      toContextValue(nextStageContext.pad),
      "Pozo 1",
      toContextValue(nextStageContext.primary.well),
      "Etapa 1",
      toContextValue(nextStageContext.primary.stage),
    ],
    [
      "Pozo 2",
      nextStageSecondaryEnabled ? toContextValue(nextStageContext.secondary.well) : "No aplica",
      "Etapa 2",
      nextStageSecondaryEnabled ? toContextValue(nextStageContext.secondary.stage) : "No aplica",
      "Aviso previo min",
      interstagePlan.stageLeadMinutes,
    ],
    [],
    [headerCell("Indicador"), headerCell("Valor"), headerCell("Detalle"), null, null, null],
    ["Objetivo entre etapa (min)", interstagePlan.targetMinutes, "Tiempo solicitado por cliente"],
    [
      "Estimacion exportada (min)",
      Number(formatMinutes(interstageMetrics.projectedMinutes)),
      interstageMetrics.similarAverageSeconds !== null
        ? "Historico similar"
        : "Base operativa + tarea critica",
    ],
    [
      "Margen vs objetivo (min)",
      Number(formatMinutes(Math.abs(projectedDelta))),
      projectedDelta > 0 ? "Sobre objetivo" : "Margen disponible",
    ],
    ["Base operativa (min)", BASE_OPERATION_MINUTES, "No acumulativa"],
    [
      "Tarea critica (min)",
      interstageMetrics.criticalTaskMinutes,
      "Mayor duracion individual cargada",
    ],
    [
      "Criterio tiempo",
      "No acumulativo",
      "Las tareas PE/IEM pueden realizarse en simultaneo",
    ],
    ["Tareas totales", interstagePlan.tasks.length, ""],
    ["Tareas completadas", interstageMetrics.completedTaskCount, ""],
    ["Tareas PE", interstageMetrics.taskCounts.pe, ""],
    ["Tareas IEM", interstageMetrics.taskCounts.iem, ""],
    [
      "Historico similar (min)",
      interstageMetrics.similarAverageSeconds !== null
        ? Number(formatMinutes(interstageMetrics.similarAverageSeconds / 60))
        : "",
      `${interstageMetrics.similarHistoryCount} registros`,
    ],
    [
      `Historico SET ${selectedSet} (min)`,
      interstageMetrics.setAverageSeconds !== null
        ? Number(formatMinutes(interstageMetrics.setAverageSeconds / 60))
        : "",
      `${interstageMetrics.setHistoryCount} registros`,
    ],
    ["Cronometro", formatClock(interstageMetrics.elapsedSeconds), ""],
    ["Inicio caudal 0", dateOrEmptyCell(interstagePlan.startedAt), ""],
    ["Cierre caudal 15 BPM", dateOrEmptyCell(interstagePlan.endedAt), ""],
    ["Nota", interstagePlan.note.trim(), ""],
    [],
    [metricCell("Mensaje operativo"), null, null, null, null, null],
    [wrappedTextCell(interstageMessage, 6), null, null, null, null, null],
  ];

  const maintenanceHeaders = [
    "Fecha exportacion",
    "SET",
    "Proxima etapa",
    "Modalidad",
    "Pad",
    "Pozo 1",
    "Etapa 1",
    "Pozo 2",
    "Etapa 2",
    "Departamento",
    "Zona",
    "SAP bomba",
    "Accion",
    "Tablero",
    "Posicion tablero",
    "Personal",
    "Detalle",
    "Estimado min",
    "Completada",
    "Creada",
  ];
  const maintenanceData: SheetData = [maintenanceHeaders.map(headerCell)];

  if (interstagePlan.tasks.length === 0) {
    maintenanceData.push([
      dateCell(exportDate),
      selectedSet,
      nextStageLabel,
      getWellStageModeLabel(nextStageContext),
      toOptionalContextValue(nextStageContext.pad),
      toOptionalContextValue(nextStageContext.primary.well),
      toOptionalContextValue(nextStageContext.primary.stage),
      nextStageSecondaryEnabled ? toOptionalContextValue(nextStageContext.secondary.well) : "",
      nextStageSecondaryEnabled ? toOptionalContextValue(nextStageContext.secondary.stage) : "",
      "Sin tareas cargadas",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
    ]);
  } else {
    interstagePlan.tasks.forEach((task) => {
      maintenanceData.push([
        dateCell(exportDate),
        selectedSet,
        nextStageLabel,
        getWellStageModeLabel(nextStageContext),
        toOptionalContextValue(nextStageContext.pad),
        toOptionalContextValue(nextStageContext.primary.well),
        toOptionalContextValue(nextStageContext.primary.stage),
        nextStageSecondaryEnabled ? toOptionalContextValue(nextStageContext.secondary.well) : "",
        nextStageSecondaryEnabled ? toOptionalContextValue(nextStageContext.secondary.stage) : "",
        INTERSTAGE_DEPARTMENT_LABELS[task.department],
        task.area.trim(),
        task.pumpSap.trim(),
        task.action.trim(),
        task.board.trim(),
        task.boardPosition.trim(),
        task.crew.trim(),
        task.detail.trim(),
        task.estimatedMinutes,
        toYesNo(task.completed),
        dateOrEmptyCell(task.createdAt),
      ]);
    });
  }

  const interstageHistoryData: SheetData = [
    [
      "SET",
      "Pozo/etapa",
      "Firma tareas",
      "Tareas",
      "Tareas PE",
      "Tareas IEM",
      "Objetivo min",
      "Inicio caudal 0",
      "Cierre caudal 15 BPM",
      "Duracion min",
      "Duracion seg",
      "Detalle tareas",
    ].map(headerCell),
  ];

  if (interstageHistory.length === 0) {
    interstageHistoryData.push([
      selectedSet,
      "Sin registros historicos",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
    ]);
  } else {
    interstageHistory.forEach((record) => {
      interstageHistoryData.push([
        record.setNumber,
        record.stageLabel,
        record.signature,
        record.taskCount,
        record.peTaskCount,
        record.iemTaskCount,
        record.targetMinutes,
        dateOrEmptyCell(record.startedAt),
        dateOrEmptyCell(record.endedAt),
        Number(formatMinutes(record.durationSeconds / 60)),
        Math.round(record.durationSeconds),
        record.tasks
          .map(
            (task) =>
              `${INTERSTAGE_DEPARTMENT_LABELS[task.department]} | ${task.pumpSap || "S/D"} | ${
                task.action || "tarea"
              } | ${task.area || "sin zona"}`,
          )
          .join("\n"),
      ]);
    });
  }

  const operationalEventData: SheetData = [
    [
      "Fecha alerta",
      "Prioridad",
      "Bomba OFFLINE",
      "Motivo OFFLINE",
      "Categoria",
      "Responsable",
      "Circuito",
      "Manifold",
      "Ubicacion",
      "Bomba reemplazo",
      "Mensaje del pop-up / accion indicada",
      "Resultado",
      "Comentario de respuesta",
      "Fecha respuesta",
    ].map(headerCell),
  ];

  if (operationalEvents.length === 0) {
    operationalEventData.push([
      "Sin alertas operativas registradas",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
    ]);
  } else {
    operationalEvents.forEach((event) => {
      operationalEventData.push([
        dateOrEmptyCell(event.createdAt),
        event.priority,
        event.pumpSap,
        event.offlineReason,
        event.category,
        event.department,
        event.lineLabel,
        event.manifoldLabel,
        event.locationNumber,
        event.replacementPumpSap ?? "",
        event.recommendedAction,
        event.decision === "ok"
          ? "OK"
          : event.decision === "not-possible"
            ? "No se puede realizar"
            : "Pendiente",
        event.responseComment,
        dateOrEmptyCell(event.respondedAt),
      ]);
    });
  }

  const dictionaryData: SheetData = [
    ["Grupo", "Campo recomendado", "Estado", "Uso para trazabilidad y prediccion"].map(headerCell),
    ...RECOMMENDED_FIELDS,
  ];
  const fileDate = createLocalTimestamp(exportDate);
  const fileName = `LUCTIV_${createFileSlug((stageContext.pad ?? "").trim() || stageContext.primary.well)}_${fileDate}.xlsx`;

  await writeXlsxFile(
    [
      {
        data: summaryData,
        sheet: "Resumen",
        columns: [{ width: 29 }, { width: 28 }, { width: 20 }, { width: 28 }],
        stickyRowsCount: 1,
        showGridLines: false,
      },
      {
        data: pumpData,
        sheet: "Bombas",
        columns: [
          { width: 21 }, { width: 20 }, { width: 8 }, { width: 14 }, { width: 20 }, { width: 12 },
          { width: 20 }, { width: 12 }, { width: 10 }, { width: 10 }, { width: 16 }, { width: 34 },
          { width: 16 }, { width: 16 }, { width: 16 }, { width: 8 }, { width: 19 }, { width: 16 },
          { width: 25 }, { width: 10 }, { width: 17 }, { width: 15 }, { width: 34 }, { width: 9 },
          { width: 9 }, { width: 9 }, { width: 17 }, { width: 14 },
        ],
        stickyRowsCount: 1,
        showGridLines: false,
      },
      {
        data: manifoldData,
        sheet: "Manifolds",
        columns: [{ width: 18 }, { width: 14 }, { width: 18 }, { width: 20 }, { width: 14 }, { width: 18 }],
        stickyRowsCount: 1,
        showGridLines: false,
      },
      {
        data: slotData,
        sheet: "Slots y actuadores",
        columns: [
          { width: 18 },
          { width: 16 },
          { width: 16 },
          { width: 8 },
          { width: 12 },
          { width: 16 },
          { width: 22 },
        ],
        stickyRowsCount: 1,
        showGridLines: false,
      },
      {
        data: interstageSummaryData,
        sheet: "Entre etapa",
        columns: [
          { width: 26 },
          { width: 28 },
          { width: 24 },
          { width: 28 },
          { width: 24 },
          { width: 34 },
        ],
        stickyRowsCount: 1,
        showGridLines: false,
      },
      {
        data: maintenanceData,
        sheet: "Mantenimiento",
        columns: [
          { width: 21 },
          { width: 8 },
          { width: 30 },
          { width: 14 },
          { width: 18 },
          { width: 14 },
          { width: 12 },
          { width: 14 },
          { width: 12 },
          { width: 20 },
          { width: 22 },
          { width: 12 },
          { width: 18 },
          { width: 10 },
          { width: 16 },
          { width: 28 },
          { width: 38 },
          { width: 14 },
          { width: 13 },
          { width: 21 },
        ],
        stickyRowsCount: 1,
        showGridLines: false,
      },
      {
        data: interstageHistoryData,
        sheet: "Historial entre etapa",
        columns: [
          { width: 8 },
          { width: 32 },
          { width: 36 },
          { width: 10 },
          { width: 12 },
          { width: 12 },
          { width: 14 },
          { width: 21 },
          { width: 21 },
          { width: 14 },
          { width: 14 },
          { width: 56 },
        ],
        stickyRowsCount: 1,
        showGridLines: false,
      },
      {
        data: operationalEventData,
        sheet: "Alertas operativas",
        columns: [
          { width: 21 },
          { width: 10 },
          { width: 16 },
          { width: 28 },
          { width: 18 },
          { width: 16 },
          { width: 12 },
          { width: 18 },
          { width: 12 },
          { width: 18 },
          { width: 58 },
          { width: 24 },
          { width: 48 },
          { width: 21 },
        ],
        stickyRowsCount: 1,
        showGridLines: false,
      },
      {
        data: dictionaryData,
        sheet: "Datos para analisis",
        columns: [{ width: 20 }, { width: 48 }, { width: 26 }, { width: 72 }],
        stickyRowsCount: 1,
        showGridLines: false,
      },
    ],
    {
      fontFamily: "Calibri",
      fontSize: 11,
    },
  ).toFile(fileName);

  return fileName;
}
